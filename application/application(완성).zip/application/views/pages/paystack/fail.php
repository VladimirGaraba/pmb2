<?php
/**
 * Created By Trimmytech
 * Fiverr Handle : @trimmytech
 * Date: 4/15/2018
 * Time: 1:51 PM
 */
?>
<html>
<head>
    <title>Payment Failed </title>
</head>
<body>
<div>
    <h1><font color="red"><strong>Payment Failed !!!!!!</strong></font></h1>
    <p>Payment failed !!.</p>
    <hr>
    <p>Having trouble with this paystack script ??<a href="mail:trimmytech@gmail.com">Contact us</a>
    </p>
    <p><a class="btn btn-primary btn-sm" href="" role="button">Continue to homepage</a></p>
</div>
</body>
</html>