<!-- Page Title
============================================= -->
<section id="page-title" class="page-title-parallax page-title-dark" style="background-image: url('<?php echo base_url(); ?>front/images/pay.jpg'); background-size: cover; padding: 120px 0;" data-bottom-top="
	background-position:0px 0px;" data-top-bottom="background-position:0px -300px;">
	<div class="container clearfix">
		<h1>How To Play</h1>
	</div>
</section><!-- #page-title end -->

<!-- Content
============================================= -->
<section id="content">
	<div class="content-wrap">
		<div class="container center clearfix">
			<div class="col_full">
				<div class="heading-block center nobottomborder">
					<h2>Our Mission</h2>
				</div>
				<p>Pay my bills club is not a get rich site, its not  a ponzi scheme neither is it a lottery or betting platform. Its  a social networking  platform created to reduce or if possible to eradicate poverty in our society. </p>

				<p><p>Its ideology is far diffrent from other game site as its main objective is to reduce the level of abject poverty in our society. </p>

				Onlike other game site, Pmbclub.com is out to pay the bills of  daily lucky winners.</p>

				<p>Based on the research carried out by our specialised group of  NGO's,we found out that there are  areas where thousands of poor people wake up and go to bed with empty stomach.</p>

				<p>Our youths engeage in all manner of crimes just to feed themselves . student find it difficult to pay thier daily bills such as transportation bills, handout bills, feeding bills, house rent bills etc, "dont ask what of thier parents as there are thousands of  students paying thier school bills themselves". </p>

				<p>There are parents who find it very difficult to feed,  pay thier house rent and children school fees etc., 

				to strengthen the point, hunger has lead to increase of crime in our society making it unsafe for citizens. </p>

				<p>Pmbclub.com came up with the idea of wealth distribution through social networking .in this plateform there are  diffrent games to play from, examples are PLAY FOR SCHOOL FEES, PLAY FOR HOUSE RENT, PLAY FOR HOLIDAY PAKAGES, PLAY FOR OTHER BILLS, PLAY FOR ITEMS,  etc. </p>

				<p>With as low as #100 Naira members can fund thier wallet  and participate in the 
				daily games available , where a raffle  draw takes places at the end of the day, the lucky winners would be rewarded with %80 of  the  proceedings from the games, while the remaining %20 would be used by NGO's to locate and pay bills of people in the poorest parts of the country who can not afford 2 square mile a day.  </p>

				<p>Note that when you play a game  and your not among the lucky winners for that day, don't see it as a waste of time and resources, bear it at the back of your mind that your efforts  was used to put a smile on someone elses face, dont lose hope, keep playing you could be among the  next lucky winners.</p>
			</div>
		</div>
	</div>
</section><!-- #content end -->

		