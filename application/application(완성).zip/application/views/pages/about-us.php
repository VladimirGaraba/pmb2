<!-- Page Title
============================================= -->
<section id="page-title" class="page-title-parallax page-title-dark" style="background-image: url('<?php echo base_url(); ?>front/images/pay.jpg'); background-size: cover; padding: 120px 0;" data-bottom-top="background-position:0px 0px;" data-top-bottom="background-position:0px -300px;">

	<div class="container clearfix">
		<h1>About Us</h1>
	</div>
</section><!-- #page-title end -->

<!-- Content
============================================= -->
<section id="content">
	<div class="content-wrap">
		<div class="container center clearfix">
			<div class="col_full">
				<div class="heading-block center nobottomborder">
					<h2>Our Mission</h2>
					<h1 style="color: blue"><?php if($usercount) echo 'visitor count:'. '' .$usercount;?></h1>
				</div>
				<p>Pay my bills club is not a get rich quick website, it is not a “ponzi” scheme neither is it a lottery
				or betting platform. It is a social networking platform created to help alleviate the sufferings of
				the downtrodden and the poor, reduce and possibly eradicate poverty in our society.</p>
				<p>PMB ideology is far different from other game sites as its main objective is to reduce the level of
				abject poverty in our society and help people meet their pressing needs.</p>
				<p><p>Unlike other game site, pmbclub.com is out to pay the bills of lucky winners.</p>
				Based on the research carried out by PMBCLUB foundation which is a non-governmental
				organization (NGO) we found out that there are instances where thousands of poor people wake
				up and go to bed with empty stomachs.</p>
				<p>Our youths now engage in all manners of crimes just to feed themselves. Students find it difficult
				to pay simple bills such as transportation bills, handout bills, feeding bills, house rent bills etc,
				don’t ask “what of their parents” as there are thousands of students paying their school bills
				themselves because their parents are financially incapacitated.</p>
				<p>There are parents who find it very difficult to feed, pay their house rent and children&#39;s school fees
				etc., to strengthen the point, hunger has led to increase in crimes in our society making a lot of
				places generally unsafe for citizens.</p>
				<p>Pay my bills club is looking at the possible means of reducing abject poverty through
				redistributions of proceedings generated from playing of games. Our main focus is to solve these
				depressing needs that lead citizens of this great Nation into committing crimes.</p>
				Pmbclub.com came up with the idea of wealth redistribution. We have different games to choose
				from, examples are SCHOOL FEES, HOUSE RENT, HOLIDAY PACKAGES, BUSINESS
				FUNDING, PLAY FOR ITEMS, and also FEED THE POOR Donations. Etc.</p>
				<p>With as low as #50 Naira you can play our daily games, where an automated raffle draw by takes
				places at the end of the day, for some games and week for others. The lucky winners would be
				rewarded/ with %80 of the total proceeds, while the PMBCLUB foundation team uses %20 of
				the total proceeds to locate and pay bills of people in the poorest parts of the country who can
				barely afford 2 square meals per day.</p>
				<p>Note that when you play a game and you are not among the lucky winners for that day, don&#39;t see
				it as a waste of time and resources, bear it at the back of your mind that your efforts has been
				used to put a smile on someone else&#39;s face, Never lose hope, keep playing you could be among
				the next lucky winners.</p>
				<p>Active members with urgent pressing needs can get help through (PMBCLUB foundation) a
				non-governmental organization. (NGO)</p>
			</div>
		</div>
	</div>
</section><!-- #content end -->

		