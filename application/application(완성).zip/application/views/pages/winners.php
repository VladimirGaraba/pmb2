<!-- Page Title
============================================= -->
<section id="page-title" class="page-title-parallax page-title-dark" style="background-image: url('<?php echo base_url(); ?>front/images/pay.jpg'); background-size: cover; padding: 120px 0;" data-bottom-top="background-position:0px 0px;" data-top-bottom="background-position:0px -300px;">
	<div class="container clearfix">
		<h1>Latest Winners</h1>
	</div>
</section><!-- #page-title end -->

<!-- Content
============================================= -->
<section id="content">
	<div class="content-wrap">
		<div class="container center clearfix">
			<div class="col_full">
				<div class="heading-block center nobottomborder">
					<h2>Winners</h2>
				</div>
				<ul class="testimonials-grid grid-3 clearfix">
					<li>
						<div class="testimonial">
							<div class="testi-content">
							    <div class="title-block">
									<h3>Play For School Fees</h3>
									<span>PIN 345678650</span>
									<span>Won ₦30,000</span>
								</div>
								<div class="testi-meta">
									Date: 24 hours ago
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="testimonial">
							<div class="testi-content">
							    <div class="title-block">
									<h3>Play For School Fees</h3>
									<span>PIN 345678650</span>
									<span>Won ₦30,000</span>
								</div>
								<div class="testi-meta">
									Date: 24 hours ago
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="testimonial">
							<div class="testi-content">
							    <div class="title-block">
									<h3>Play For School Fees</h3>
									<span>PIN 345678650</span>
									<span>Won ₦30,000</span>
								</div>
								<div class="testi-meta">
									Date: 24 hours ago
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="testimonial">
							<div class="testi-content">
							    <div class="title-block">
									<h3>Play For School Fees</h3>
									<span>PIN 345678650</span>
									<span>Won ₦30,000</span>
								</div>
								<div class="testi-meta">
									Date: 24 hours ago
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="testimonial">
							<div class="testi-content">
							    <div class="title-block">
									<h3>Play For School Fees</h3>
									<span>PIN 345678650</span>
									<span>Won ₦30,000</span>
								</div>
								<div class="testi-meta">
									Date: 24 hours ago
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="testimonial">
							<div class="testi-content">
							    <div class="title-block">
									<h3>Play For School Fees</h3>
									<span>PIN 345678650</span>
									<span>Won ₦30,000</span>
								</div>
								<div class="testi-meta">
									Date: 24 hours ago
								</div>
							</div>
						</div>
					</li>
				</ul>
			</div>
		</div>
	</div>
</section><!-- #content end -->

		