
<!-- Page Title
============================================= -->
<section id="page-title" class="page-title-parallax page-title-dark" style="background-image: url('<?php echo base_url(); ?>front/images/pay.jpg'); background-size: cover; padding: 120px 0;" data-bottom-top="background-position:0px 0px;" data-top-bottom="background-position:0px -300px;">

	<div class="container clearfix">
		<h1>Play Now</h1>
	</div>

</section><!-- #page-title end -->

<!-- Content
============================================= -->
<section id="content">
	<?php $this->load->view('pages/play-categories');?>
	<?php $this->load->view('pages/testimonials');?>
</section><!-- #content end -->

		