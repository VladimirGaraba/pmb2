<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-12 00:59:48 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\user-templates\header.php 5
ERROR - 2019-06-12 01:01:10 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\user-templates\header.php 5
ERROR - 2019-06-12 01:01:16 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\user-templates\header.php 5
ERROR - 2019-06-12 01:01:36 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\user-templates\header.php 5
ERROR - 2019-06-12 01:01:41 --> 404 Page Not Found: Users_dashboard/dashboard
ERROR - 2019-06-12 01:01:55 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\user-templates\header.php 5
ERROR - 2019-06-12 01:02:11 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\user-templates\header.php 5
ERROR - 2019-06-12 01:08:32 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\user-templates\header.php 5
ERROR - 2019-06-12 11:33:28 --> Severity: Compile Error --> Can't use method return value in write context F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Auth.php 28
ERROR - 2019-06-12 11:34:42 --> Severity: Compile Error --> Can't use method return value in write context F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Auth.php 28
ERROR - 2019-06-12 11:34:43 --> Severity: Compile Error --> Can't use method return value in write context F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Auth.php 28
ERROR - 2019-06-12 11:34:43 --> Severity: Compile Error --> Can't use method return value in write context F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Auth.php 28
ERROR - 2019-06-12 11:34:44 --> Severity: Compile Error --> Can't use method return value in write context F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Auth.php 28
ERROR - 2019-06-12 11:34:44 --> Severity: Compile Error --> Can't use method return value in write context F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Auth.php 28
ERROR - 2019-06-12 11:34:47 --> Severity: Compile Error --> Can't use method return value in write context F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Auth.php 28
ERROR - 2019-06-12 11:43:27 --> Query error: Duplicate entry '20' for key 'PRIMARY' - Invalid query: INSERT INTO `user_relation_table` (`user_id`, `complaint_title`, `content`, `complaint_day`) VALUES ('20', 'dsfs', 'fdf', '2019-06-12')
ERROR - 2019-06-12 12:29:38 --> Severity: Compile Error --> Cannot redeclare Paystack::success() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Paystack.php 162
ERROR - 2019-06-12 12:31:51 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 12:31:52 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 12:31:52 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 12:31:53 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 12:31:53 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 12:31:53 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 12:31:53 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 12:31:53 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 12:31:54 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 12:31:54 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 12:31:54 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 12:31:54 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 12:31:55 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 12:31:55 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 13:38:42 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:38:42 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:38:42 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:38:42 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:38:42 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:38:42 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:11 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:11 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:12 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:12 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:12 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:12 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:13 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:13 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:14 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:14 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:14 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:14 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:15 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:15 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:16 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:16 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:16 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:16 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:16 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:16 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:16 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:16 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:17 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:17 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:17 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:17 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:17 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:17 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:19 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:19 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:20 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:20 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:20 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:20 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:20 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:20 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:21 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:21 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:21 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:21 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:21 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:21 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:22 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:22 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:22 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:22 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:22 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:22 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:23 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:23 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:23 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:23 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:30 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:30 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:30 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:30 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:30 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:30 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:32 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:32 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:32 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:32 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:33 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:33 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:33 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:33 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:34 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:34 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:35 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:35 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:36 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:36 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:36 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:36 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:37 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:37 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:41 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:41 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:42 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:42 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:42 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:42 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:42 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:42 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:43 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:43 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:43 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:43 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:44 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:44 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:44 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:44 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:45 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:45 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:46 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:46 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:46 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:46 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:47 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:47 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:47 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:47 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:47 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:47 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:48 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:48 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:49 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:49 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:55 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:55 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:55 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:55 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:56 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:56 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:56 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:56 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:57 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:57 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:57 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:57 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:58 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:58 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:59 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:59 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:59 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:59 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:59 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:39:59 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:39:59 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:00 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:00 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:00 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:01 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:01 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:01 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:01 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:02 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:02 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:03 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:03 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:03 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:03 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:03 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:03 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:04 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:04 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:04 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:04 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:04 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:04 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:05 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:05 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:05 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:05 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:05 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:05 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:05 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:05 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:06 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:06 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:07 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:07 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:08 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:08 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:08 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:08 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:09 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:09 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:25 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:25 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:25 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:25 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:26 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:26 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:26 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:26 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:26 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:26 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:26 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:26 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:27 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:27 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:27 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:27 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:28 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:28 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:28 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:28 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:28 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:28 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:28 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:28 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:29 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:29 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:29 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:29 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:29 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:29 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:29 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:29 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:29 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:29 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:30 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:30 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:30 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:30 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:43 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:43 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:44 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:44 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:44 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:44 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:44 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:44 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:44 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:44 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:45 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:45 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:46 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:46 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:46 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:46 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:47 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:47 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:47 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:47 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:47 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:47 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:51 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:51 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:52 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:52 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:53 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:53 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:54 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:54 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:55 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:55 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:55 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:55 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:56 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:56 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:57 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:57 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:57 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:57 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:58 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:58 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:59 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:59 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:40:59 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:40:59 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:48:16 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:48:16 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:48:16 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:48:16 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:48:17 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:48:17 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:48:18 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:48:18 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:48:18 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:48:18 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:48:19 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:48:19 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:48:20 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:48:20 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:49:49 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:49:49 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:49:50 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:49:50 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:49:51 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:49:51 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:49:51 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:49:51 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:49:51 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:49:51 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:49:52 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:49:52 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:49:52 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:49:52 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:49:52 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:49:52 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:49:52 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:49:52 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:49:53 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:49:53 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:49:53 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:49:53 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:49:53 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:49:53 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:50:07 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:50:07 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:50:08 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:50:08 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:50:08 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:50:08 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:50:08 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:50:08 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:50:09 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:50:09 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:50:10 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:50:10 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:50:10 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:50:10 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:50:10 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:50:10 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:50:12 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:50:12 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:50:14 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:50:14 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:50:16 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-12 13:50:16 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-12 13:51:17 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 13:56:05 --> Severity: error --> Exception: Too few arguments to function Paystack::index(), 0 passed in F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\CodeIgniter.php on line 532 and exactly 1 expected F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Paystack.php 20
ERROR - 2019-06-12 13:56:30 --> Severity: error --> Exception: Too few arguments to function Paystack::index(), 0 passed in F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\CodeIgniter.php on line 532 and exactly 1 expected F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Paystack.php 20
ERROR - 2019-06-12 13:56:31 --> Severity: error --> Exception: Too few arguments to function Paystack::index(), 0 passed in F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\CodeIgniter.php on line 532 and exactly 1 expected F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Paystack.php 20
ERROR - 2019-06-12 13:56:32 --> Severity: error --> Exception: Too few arguments to function Paystack::index(), 0 passed in F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\CodeIgniter.php on line 532 and exactly 1 expected F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Paystack.php 20
ERROR - 2019-06-12 13:56:32 --> Severity: error --> Exception: Too few arguments to function Paystack::index(), 0 passed in F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\CodeIgniter.php on line 532 and exactly 1 expected F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Paystack.php 20
ERROR - 2019-06-12 13:56:32 --> Severity: error --> Exception: Too few arguments to function Paystack::index(), 0 passed in F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\CodeIgniter.php on line 532 and exactly 1 expected F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Paystack.php 20
ERROR - 2019-06-12 13:56:32 --> Severity: error --> Exception: Too few arguments to function Paystack::index(), 0 passed in F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\CodeIgniter.php on line 532 and exactly 1 expected F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Paystack.php 20
ERROR - 2019-06-12 13:56:33 --> Severity: error --> Exception: Too few arguments to function Paystack::index(), 0 passed in F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\CodeIgniter.php on line 532 and exactly 1 expected F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Paystack.php 20
ERROR - 2019-06-12 13:56:33 --> Severity: error --> Exception: Too few arguments to function Paystack::index(), 0 passed in F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\CodeIgniter.php on line 532 and exactly 1 expected F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Paystack.php 20
ERROR - 2019-06-12 13:56:33 --> Severity: error --> Exception: Too few arguments to function Paystack::index(), 0 passed in F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\CodeIgniter.php on line 532 and exactly 1 expected F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Paystack.php 20
ERROR - 2019-06-12 13:56:34 --> Severity: error --> Exception: Too few arguments to function Paystack::index(), 0 passed in F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\CodeIgniter.php on line 532 and exactly 1 expected F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Paystack.php 20
ERROR - 2019-06-12 13:56:35 --> Severity: error --> Exception: Too few arguments to function Paystack::index(), 0 passed in F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\CodeIgniter.php on line 532 and exactly 1 expected F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Paystack.php 20
ERROR - 2019-06-12 13:56:54 --> Severity: error --> Exception: Too few arguments to function Paystack::index(), 0 passed in F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\CodeIgniter.php on line 532 and exactly 1 expected F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Paystack.php 20
ERROR - 2019-06-12 13:57:20 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 13:58:18 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 13:58:19 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 13:58:19 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 13:58:19 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 13:58:20 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 13:58:20 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 13:58:20 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 13:58:32 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 13:58:32 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 13:58:32 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 13:58:33 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 13:58:41 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 65
ERROR - 2019-06-12 13:58:41 --> 404 Page Not Found: PaystackArray/index
ERROR - 2019-06-12 14:00:06 --> 404 Page Not Found: PaystackArray/index
ERROR - 2019-06-12 14:00:06 --> 404 Page Not Found: PaystackArray/index
ERROR - 2019-06-12 14:00:06 --> 404 Page Not Found: PaystackArray/index
ERROR - 2019-06-12 14:00:07 --> 404 Page Not Found: PaystackArray/index
ERROR - 2019-06-12 14:00:07 --> 404 Page Not Found: PaystackArray/index
ERROR - 2019-06-12 14:00:15 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 65
ERROR - 2019-06-12 14:00:15 --> 404 Page Not Found: Paystack/Array
ERROR - 2019-06-12 14:28:25 --> 404 Page Not Found: Paystack/Array
ERROR - 2019-06-12 14:28:26 --> 404 Page Not Found: Paystack/Array
ERROR - 2019-06-12 14:28:29 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 14:28:33 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 14:28:34 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 14:28:35 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 14:28:36 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 14:28:38 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 14:28:39 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 14:28:55 --> Severity: Warning --> Use of undefined constant PAYSTACK_PUBLIC_KEY - assumed 'PAYSTACK_PUBLIC_KEY' (this will throw an Error in a future version of PHP) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 15:02:17 --> Severity: error --> Exception: Call to undefined function paystack_inline() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 74
ERROR - 2019-06-12 15:02:23 --> Severity: error --> Exception: Call to undefined function paystack_inline() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 74
ERROR - 2019-06-12 15:02:25 --> Severity: error --> Exception: Call to undefined function paystack_inline() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 74
ERROR - 2019-06-12 15:03:11 --> Severity: error --> Exception: Call to undefined function paystack_inline() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 74
ERROR - 2019-06-12 15:03:13 --> Severity: error --> Exception: Call to undefined function paystack_inline() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 74
ERROR - 2019-06-12 15:03:14 --> Severity: error --> Exception: Call to undefined function paystack_inline() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 74
ERROR - 2019-06-12 15:03:31 --> 404 Page Not Found: Paystack_inline/index
ERROR - 2019-06-12 15:05:49 --> 404 Page Not Found: Paystack_inline/index
ERROR - 2019-06-12 15:05:50 --> 404 Page Not Found: Paystack_inline/index
ERROR - 2019-06-12 15:05:50 --> 404 Page Not Found: Paystack_inline/index
ERROR - 2019-06-12 15:05:51 --> 404 Page Not Found: Paystack_inline/index
ERROR - 2019-06-12 15:05:51 --> 404 Page Not Found: Paystack_inline/index
ERROR - 2019-06-12 15:05:51 --> 404 Page Not Found: Paystack_inline/index
ERROR - 2019-06-12 15:05:51 --> 404 Page Not Found: Paystack_inline/index
ERROR - 2019-06-12 15:05:52 --> 404 Page Not Found: Paystack_inline/index
ERROR - 2019-06-12 15:05:52 --> 404 Page Not Found: Paystack_inline/index
ERROR - 2019-06-12 15:05:52 --> 404 Page Not Found: Paystack_inline/index
ERROR - 2019-06-12 15:05:52 --> 404 Page Not Found: Paystack_inline/index
ERROR - 2019-06-12 15:05:53 --> 404 Page Not Found: Paystack_inline/index
ERROR - 2019-06-12 15:06:02 --> 404 Page Not Found: Paystack_inline/index
ERROR - 2019-06-12 15:06:03 --> 404 Page Not Found: Paystack_inline/index
ERROR - 2019-06-12 15:06:03 --> 404 Page Not Found: Paystack_inline/index
ERROR - 2019-06-12 15:06:03 --> 404 Page Not Found: Paystack_inline/index
ERROR - 2019-06-12 15:06:23 --> Severity: Warning --> Illegal string offset 'title' F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 174
ERROR - 2019-06-12 15:06:23 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 15:06:23 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:06:23 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:09:02 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 15:09:02 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:09:02 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:09:03 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 15:09:03 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:09:03 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:09:04 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 15:09:04 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:09:04 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:09:04 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 15:09:04 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:09:04 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:09:05 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 15:09:05 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:09:05 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:11:58 --> 404 Page Not Found: Pay/index
ERROR - 2019-06-12 15:12:00 --> 404 Page Not Found: Pay/index
ERROR - 2019-06-12 15:12:00 --> 404 Page Not Found: Pay/index
ERROR - 2019-06-12 15:12:01 --> 404 Page Not Found: Pay/index
ERROR - 2019-06-12 15:12:01 --> 404 Page Not Found: Pay/index
ERROR - 2019-06-12 15:12:02 --> 404 Page Not Found: Pay/index
ERROR - 2019-06-12 15:12:02 --> 404 Page Not Found: Pay/index
ERROR - 2019-06-12 15:12:34 --> 404 Page Not Found: Pay/index
ERROR - 2019-06-12 15:12:42 --> 404 Page Not Found: Pay/index
ERROR - 2019-06-12 15:12:43 --> 404 Page Not Found: Pay/index
ERROR - 2019-06-12 15:12:43 --> 404 Page Not Found: Pay/index
ERROR - 2019-06-12 15:12:43 --> 404 Page Not Found: Pay/index
ERROR - 2019-06-12 15:13:15 --> Severity: Warning --> Illegal string offset 'title' F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 174
ERROR - 2019-06-12 15:13:15 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 16
ERROR - 2019-06-12 15:13:15 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 15:13:15 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:13:15 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:19:33 --> 404 Page Not Found: Pay/index
ERROR - 2019-06-12 15:19:34 --> 404 Page Not Found: Pay/index
ERROR - 2019-06-12 15:19:34 --> 404 Page Not Found: Pay/index
ERROR - 2019-06-12 15:19:35 --> 404 Page Not Found: Pay/index
ERROR - 2019-06-12 15:19:53 --> Severity: Notice --> Undefined variable: id F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 74
ERROR - 2019-06-12 15:19:53 --> 404 Page Not Found: Pay/index
ERROR - 2019-06-12 15:23:35 --> 404 Page Not Found: Pay/index
ERROR - 2019-06-12 15:23:35 --> 404 Page Not Found: Pay/index
ERROR - 2019-06-12 15:23:53 --> Severity: Warning --> Illegal string offset 'title' F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 174
ERROR - 2019-06-12 15:23:53 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 16
ERROR - 2019-06-12 15:23:53 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 15:23:53 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:23:53 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:26:10 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 15:26:10 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:26:10 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:26:13 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 15:26:13 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:26:13 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:26:52 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 15:26:52 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:26:52 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:37:46 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 15:37:46 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:37:46 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:37:47 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 15:37:47 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:37:47 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:37:47 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 15:37:47 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:37:47 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:37:48 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 15:37:48 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:37:48 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:37:49 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 15:37:49 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:37:49 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:38:27 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 110
ERROR - 2019-06-12 15:38:27 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:38:27 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:39:44 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:39:44 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:39:44 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:39:47 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:39:48 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:39:48 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:39:48 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:39:48 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:39:48 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:39:49 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:39:49 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:39:49 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:40:08 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:40:08 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:40:08 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:40:09 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:40:09 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:40:09 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:40:09 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:40:09 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:40:09 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:40:10 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:40:10 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:40:10 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:40:10 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:40:10 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:40:10 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:40:10 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:40:10 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:40:10 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:40:11 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:40:11 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:40:11 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:40:28 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:40:28 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:40:28 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:40:29 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:40:29 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:40:29 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:40:30 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:40:30 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:40:30 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:40:30 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:40:30 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:40:30 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:40:30 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:40:30 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:40:30 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:40:30 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:40:30 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:40:30 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:40:30 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:40:30 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:40:30 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:40:48 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:40:48 --> Severity: Notice --> Undefined variable: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:40:48 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 112
ERROR - 2019-06-12 15:48:41 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:48:41 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:48:42 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:48:42 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:02 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:02 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:03 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:03 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:03 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:03 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:04 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:04 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:04 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:04 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:04 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:04 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:04 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:04 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:04 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:04 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:04 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:04 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:05 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:05 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:26 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:26 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:38 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:38 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:38 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:38 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:39 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:39 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:39 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:39 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:39 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:39 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:39 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:39 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:39 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:39 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:40 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:40 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:40 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:40 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:40 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:40 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:40 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:40 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:41 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:41 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:41 --> Severity: Notice --> Undefined variable: query F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:49:41 --> Severity: error --> Exception: Call to a member function row_array() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 177
ERROR - 2019-06-12 15:50:05 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 184
ERROR - 2019-06-12 15:50:05 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:50:05 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:51:16 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 184
ERROR - 2019-06-12 15:51:16 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:51:16 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:51:17 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 184
ERROR - 2019-06-12 15:51:17 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:51:17 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:51:17 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 184
ERROR - 2019-06-12 15:51:17 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:51:17 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:51:17 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 184
ERROR - 2019-06-12 15:51:17 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:51:17 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:51:17 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 184
ERROR - 2019-06-12 15:51:17 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:51:17 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:51:18 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 184
ERROR - 2019-06-12 15:51:18 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:51:18 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:51:35 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 184
ERROR - 2019-06-12 15:51:35 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:51:35 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:51:43 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 184
ERROR - 2019-06-12 15:51:43 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:51:43 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:51:44 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 184
ERROR - 2019-06-12 15:51:44 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:51:44 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:51:44 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 184
ERROR - 2019-06-12 15:51:44 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:51:44 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:51:44 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 184
ERROR - 2019-06-12 15:51:44 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:51:44 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:51:44 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 184
ERROR - 2019-06-12 15:51:44 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:51:44 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:51:44 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 184
ERROR - 2019-06-12 15:51:44 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:51:44 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:51:45 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 184
ERROR - 2019-06-12 15:51:45 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:51:45 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:51:45 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 184
ERROR - 2019-06-12 15:51:45 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:51:45 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:51:45 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 184
ERROR - 2019-06-12 15:51:45 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:51:45 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:52:00 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 184
ERROR - 2019-06-12 15:52:00 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:52:00 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:52:48 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:52:48 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:53:35 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:53:35 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:53:37 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:53:37 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:53:38 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:53:38 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:53:38 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:53:38 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:53:39 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:53:39 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:53:40 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:53:40 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:53:40 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:53:40 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:53:40 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:53:40 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:53:40 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:53:40 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:53:41 --> Severity: Notice --> Undefined variable: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 83
ERROR - 2019-06-12 15:53:41 --> Severity: Notice --> Undefined variable: Email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 111
ERROR - 2019-06-12 15:55:30 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:55:30 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:57:31 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:57:31 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:57:32 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:57:32 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:57:32 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:57:32 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:57:33 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:57:33 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:57:33 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:57:33 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:57:33 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:57:34 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:57:34 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:57:34 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:57:34 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:57:34 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:57:34 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:57:34 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:57:34 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:57:34 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:57:51 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:57:51 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:58:46 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:58:46 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:58:47 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:58:47 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:58:47 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:58:47 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:58:48 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:58:48 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:58:48 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:58:48 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:58:48 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:58:48 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:58:49 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:58:49 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:58:49 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:58:49 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:58:49 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:58:49 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:58:49 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:58:49 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:58:50 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:58:50 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:58:50 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:58:50 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:58:51 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:58:51 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:58:51 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:58:51 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:58:51 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:58:51 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:58:52 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:58:52 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:59:13 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:59:13 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:59:49 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:59:49 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:59:50 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:59:50 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 15:59:51 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 15:59:51 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:00:23 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:00:23 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:03:16 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:03:16 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:03:18 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:03:18 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:03:19 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:03:19 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:03:20 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:03:20 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:03:20 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:03:20 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:05:37 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:05:37 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:06:11 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:06:11 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:06:12 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:06:12 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:06:13 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:06:13 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:06:13 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:06:13 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:06:14 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:06:14 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:06:14 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:06:14 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:06:15 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:06:15 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:06:16 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:06:16 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:06:16 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:06:16 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:06:16 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:06:16 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:06:17 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:06:17 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:06:29 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:06:29 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:06:30 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:06:30 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:06:30 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:06:30 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:06:31 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:06:31 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:06:31 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:06:31 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:06:39 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:06:39 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:06:57 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:06:57 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:06:58 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:06:58 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:06:59 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:06:59 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:06:59 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:06:59 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:07:07 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:07:07 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:07:08 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:07:08 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:07:08 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:07:08 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:07:18 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:07:18 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:07:41 --> Severity: Warning --> md5() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 106
ERROR - 2019-06-12 16:07:41 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 16:10:42 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\user-templates\header.php 5
ERROR - 2019-06-12 17:03:48 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\paystack\paystack_inline.php 107
ERROR - 2019-06-12 17:06:39 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 185
ERROR - 2019-06-12 17:06:42 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 185
ERROR - 2019-06-12 17:06:57 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 185
ERROR - 2019-06-12 17:06:58 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 185
ERROR - 2019-06-12 17:06:58 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 185
ERROR - 2019-06-12 17:06:59 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 185
ERROR - 2019-06-12 17:06:59 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 185
ERROR - 2019-06-12 17:06:59 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 185
ERROR - 2019-06-12 17:07:19 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 185
ERROR - 2019-06-12 17:07:34 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 185
ERROR - 2019-06-12 17:07:34 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 185
ERROR - 2019-06-12 17:07:34 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 185
ERROR - 2019-06-12 17:07:35 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 185
ERROR - 2019-06-12 17:07:35 --> Severity: Notice --> Undefined variable: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models\User_Model.php 185
ERROR - 2019-06-12 20:10:18 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\home.php 173
ERROR - 2019-06-12 20:20:00 --> Severity: error --> Exception: syntax error, unexpected end of file F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\home.php 252
ERROR - 2019-06-12 20:20:01 --> Severity: error --> Exception: syntax error, unexpected end of file F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\home.php 252
ERROR - 2019-06-12 20:20:02 --> Severity: error --> Exception: syntax error, unexpected end of file F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\home.php 252
ERROR - 2019-06-12 20:20:03 --> Severity: error --> Exception: syntax error, unexpected end of file F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\home.php 252
ERROR - 2019-06-12 20:20:03 --> Severity: error --> Exception: syntax error, unexpected end of file F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\home.php 252
ERROR - 2019-06-12 20:20:04 --> Severity: error --> Exception: syntax error, unexpected end of file F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\home.php 252
ERROR - 2019-06-12 20:20:35 --> Severity: error --> Exception: syntax error, unexpected end of file F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\home.php 250
ERROR - 2019-06-12 20:20:36 --> Severity: error --> Exception: syntax error, unexpected end of file F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\home.php 250
ERROR - 2019-06-12 20:20:36 --> Severity: error --> Exception: syntax error, unexpected end of file F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\home.php 250
ERROR - 2019-06-12 20:20:37 --> Severity: error --> Exception: syntax error, unexpected end of file F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\home.php 250
ERROR - 2019-06-12 20:20:37 --> Severity: error --> Exception: syntax error, unexpected end of file F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\home.php 250
ERROR - 2019-06-12 20:20:38 --> Severity: error --> Exception: syntax error, unexpected end of file F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\home.php 250
ERROR - 2019-06-12 20:20:38 --> Severity: error --> Exception: syntax error, unexpected end of file F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\home.php 250
ERROR - 2019-06-12 20:20:42 --> Severity: error --> Exception: syntax error, unexpected end of file F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\home.php 250
