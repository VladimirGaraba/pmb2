<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-26 00:20:18 --> Severity: Notice --> Undefined variable: id /home/pmbcjykk/public_html/pmb2/application/models/User_Model.php 50
ERROR - 2019-06-26 00:20:19 --> Query error: Table 'pmbcjykk_club67re98.transactions' doesn't exist - Invalid query: SELECT SUM(`Wallet`) AS `Wallet`
FROM `transactions`
WHERE `User_id` = '1'
ERROR - 2019-06-26 00:27:37 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 24
ERROR - 2019-06-26 01:14:59 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 21
ERROR - 2019-06-26 01:15:03 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 21
ERROR - 2019-06-26 01:16:30 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 21
ERROR - 2019-06-26 01:19:09 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Purchases.php 31
ERROR - 2019-06-26 01:19:16 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Purchases.php 31
ERROR - 2019-06-26 01:19:21 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Testimonials.php 31
ERROR - 2019-06-26 01:19:31 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Winnings.php 31
ERROR - 2019-06-26 01:19:47 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Supports.php 31
ERROR - 2019-06-26 01:47:40 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Supports.php 31
ERROR - 2019-06-26 01:47:58 --> Severity: Notice --> Undefined variable: money /home/pmbcjykk/public_html/pmb2/application/controllers/Withdrawals.php 30
ERROR - 2019-06-26 01:56:40 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/UserPayments.php 23
ERROR - 2019-06-26 01:57:03 --> Severity: Notice --> Trying to get property 'Name' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 117
ERROR - 2019-06-26 01:57:03 --> Severity: Notice --> Trying to get property 'Username' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 118
ERROR - 2019-06-26 01:57:03 --> Severity: Notice --> Trying to get property 'Email' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 119
ERROR - 2019-06-26 01:57:03 --> Severity: Notice --> Trying to get property 'Phone' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 120
ERROR - 2019-06-26 01:57:03 --> Severity: Notice --> Trying to get property 'Gender' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 121
ERROR - 2019-06-26 01:57:03 --> Severity: Notice --> Trying to get property 'Country' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 122
ERROR - 2019-06-26 02:06:05 --> Severity: Notice --> Trying to get property 'Name' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 117
ERROR - 2019-06-26 02:06:05 --> Severity: Notice --> Trying to get property 'Username' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 118
ERROR - 2019-06-26 02:06:05 --> Severity: Notice --> Trying to get property 'Email' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 119
ERROR - 2019-06-26 02:06:05 --> Severity: Notice --> Trying to get property 'Phone' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 120
ERROR - 2019-06-26 02:06:05 --> Severity: Notice --> Trying to get property 'Gender' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 121
ERROR - 2019-06-26 02:06:05 --> Severity: Notice --> Trying to get property 'Country' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 122
ERROR - 2019-06-26 02:17:53 --> Severity: Notice --> Undefined variable: id /home/pmbcjykk/public_html/pmb2/application/models/User_Model.php 50
ERROR - 2019-06-26 03:27:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-26 03:58:26 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-26 04:04:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-26 04:15:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-26 05:19:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-26 05:22:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-26 05:34:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-26 05:34:38 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-26 05:40:23 --> Severity: Notice --> Undefined variable: id /home/pmbcjykk/public_html/pmb2/application/models/User_Model.php 50
ERROR - 2019-06-26 05:40:23 --> Severity: Notice --> Trying to get property 'TransactionID' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 93
ERROR - 2019-06-26 05:43:33 --> Severity: Notice --> Trying to get property 'TransactionID' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 93
ERROR - 2019-06-26 05:48:16 --> Severity: Notice --> Undefined variable: id /home/pmbcjykk/public_html/pmb2/application/models/User_Model.php 50
ERROR - 2019-06-26 06:01:38 --> Severity: Notice --> Undefined property: stdClass::$BankName1 /home/pmbcjykk/public_html/pmb2/application/views/pages/admin/users.php 54
ERROR - 2019-06-26 06:01:38 --> Severity: Notice --> Undefined property: stdClass::$BankName2 /home/pmbcjykk/public_html/pmb2/application/views/pages/admin/users.php 55
ERROR - 2019-06-26 06:01:38 --> Severity: Notice --> Undefined property: stdClass::$AccountName /home/pmbcjykk/public_html/pmb2/application/views/pages/admin/users.php 56
ERROR - 2019-06-26 06:01:38 --> Severity: Notice --> Undefined property: stdClass::$AccountNumber /home/pmbcjykk/public_html/pmb2/application/views/pages/admin/users.php 57
ERROR - 2019-06-26 06:01:38 --> Severity: Notice --> Undefined property: stdClass::$BankName1 /home/pmbcjykk/public_html/pmb2/application/views/pages/admin/users.php 54
ERROR - 2019-06-26 06:01:38 --> Severity: Notice --> Undefined property: stdClass::$BankName2 /home/pmbcjykk/public_html/pmb2/application/views/pages/admin/users.php 55
ERROR - 2019-06-26 06:01:38 --> Severity: Notice --> Undefined property: stdClass::$AccountName /home/pmbcjykk/public_html/pmb2/application/views/pages/admin/users.php 56
ERROR - 2019-06-26 06:01:38 --> Severity: Notice --> Undefined property: stdClass::$AccountNumber /home/pmbcjykk/public_html/pmb2/application/views/pages/admin/users.php 57
ERROR - 2019-06-26 06:01:38 --> Severity: Notice --> Undefined property: stdClass::$BankName1 /home/pmbcjykk/public_html/pmb2/application/views/pages/admin/users.php 54
ERROR - 2019-06-26 06:01:38 --> Severity: Notice --> Undefined property: stdClass::$BankName2 /home/pmbcjykk/public_html/pmb2/application/views/pages/admin/users.php 55
ERROR - 2019-06-26 06:01:38 --> Severity: Notice --> Undefined property: stdClass::$AccountName /home/pmbcjykk/public_html/pmb2/application/views/pages/admin/users.php 56
ERROR - 2019-06-26 06:01:38 --> Severity: Notice --> Undefined property: stdClass::$AccountNumber /home/pmbcjykk/public_html/pmb2/application/views/pages/admin/users.php 57
ERROR - 2019-06-26 06:05:31 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-26 06:05:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-26 06:06:32 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-26 06:06:32 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-26 06:06:32 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-26 06:06:32 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-26 06:07:49 --> 404 Page Not Found: Demo/contact-us
ERROR - 2019-06-26 06:08:13 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-26 07:54:23 --> 404 Page Not Found: Pmbclubsql/index
ERROR - 2019-06-26 08:15:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-26 08:16:21 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-26 08:16:37 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-26 08:29:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-26 08:29:19 --> Severity: Notice --> Undefined variable: id /home/pmbcjykk/public_html/pmb2/application/models/User_Model.php 50
ERROR - 2019-06-26 08:33:29 --> Severity: Notice --> Undefined variable: users /home/pmbcjykk/public_html/pmb2/application/views/pages/user/payment-profile.php 43
ERROR - 2019-06-26 08:33:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pmbcjykk/public_html/pmb2/application/views/pages/user/payment-profile.php 43
ERROR - 2019-06-26 08:33:32 --> Severity: Notice --> Undefined variable: users /home/pmbcjykk/public_html/pmb2/application/views/pages/user/payment-profile.php 43
ERROR - 2019-06-26 08:33:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pmbcjykk/public_html/pmb2/application/views/pages/user/payment-profile.php 43
ERROR - 2019-06-26 08:49:35 --> Severity: Notice --> Undefined variable: users /home/pmbcjykk/public_html/pmb2/application/views/pages/user/payment-profile.php 43
ERROR - 2019-06-26 08:49:35 --> Severity: Notice --> Undefined variable: users /home/pmbcjykk/public_html/pmb2/application/views/pages/user/payment-profile.php 43
ERROR - 2019-06-26 08:49:35 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pmbcjykk/public_html/pmb2/application/views/pages/user/payment-profile.php 43
ERROR - 2019-06-26 08:49:35 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pmbcjykk/public_html/pmb2/application/views/pages/user/payment-profile.php 43
ERROR - 2019-06-26 09:36:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-26 09:36:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-26 09:36:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-26 09:36:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-26 10:04:25 --> Query error: Unknown column 'User_id' in 'where clause' - Invalid query: SELECT *
FROM `pay_profiles`
WHERE `User_id` = '1'
ERROR - 2019-06-26 10:05:22 --> Severity: Notice --> Undefined variable: users /home/pmbcjykk/public_html/pmb2/application/views/pages/user/payment-profile.php 42
ERROR - 2019-06-26 10:05:22 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pmbcjykk/public_html/pmb2/application/views/pages/user/payment-profile.php 42
ERROR - 2019-06-26 10:08:01 --> Severity: Notice --> Undefined variable: user /home/pmbcjykk/public_html/pmb2/application/controllers/UserPayments.php 30
ERROR - 2019-06-26 10:11:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-26 10:13:07 --> Severity: Notice --> Undefined variable: id /home/pmbcjykk/public_html/pmb2/application/models/User_Model.php 50
ERROR - 2019-06-26 10:17:42 --> Severity: error --> Exception: Too few arguments to function UserPayments::index(), 0 passed in /home/pmbcjykk/public_html/pmb2/system/core/CodeIgniter.php on line 532 and exactly 2 expected /home/pmbcjykk/public_html/pmb2/application/controllers/UserPayments.php 15
ERROR - 2019-06-26 10:20:23 --> Query error: Unknown column 'BankName1' in 'field list' - Invalid query: INSERT INTO `pay_profiles` (`UserID`, `Gateway`, `BankName1`, `AccountName`, `AccountNumber`, `Created`) VALUES ('1', 'Bank', 'second bank', 'Sterling White', '26556575655', '2019-06-26')
ERROR - 2019-06-26 10:21:34 --> 404 Page Not Found: User/payment-profile
ERROR - 2019-06-26 11:03:39 --> 404 Page Not Found: User-dashboard/add-deposit.html
ERROR - 2019-06-26 11:05:42 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-26 11:27:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-26 11:53:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-26 11:55:51 --> 404 Page Not Found: Demo/faqs
ERROR - 2019-06-26 11:56:22 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-26 11:56:22 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-26 11:56:22 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-26 11:56:22 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-26 11:57:04 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-26 11:57:58 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-26 12:11:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-26 14:31:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-26 14:31:37 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-26 16:10:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-26 16:35:49 --> 404 Page Not Found: Faviconico/index
