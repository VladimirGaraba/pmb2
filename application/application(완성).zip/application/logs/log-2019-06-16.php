<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-16 00:09:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-16 02:15:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-16 03:07:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-16 03:08:13 --> 404 Page Not Found: Send_pass/index
ERROR - 2019-06-16 03:09:34 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-16 03:09:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-16 03:21:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-16 04:47:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-16 04:48:36 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-16 06:55:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-16 07:23:45 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-16 07:59:14 --> 404 Page Not Found: Send_pass/index
ERROR - 2019-06-16 07:59:31 --> 404 Page Not Found: Front/css
ERROR - 2019-06-16 07:59:32 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-16 08:11:23 --> 404 Page Not Found: Front/css
ERROR - 2019-06-16 08:11:23 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-16 08:14:16 --> 404 Page Not Found: Front/css
ERROR - 2019-06-16 08:14:17 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-16 08:34:21 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' /home/pmbcjykk/public_html/pmb2/application/models/User_Model.php 128
ERROR - 2019-06-16 09:44:30 --> 404 Page Not Found: Admin/withdrawals-requests.html
ERROR - 2019-06-16 09:44:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-16 09:44:33 --> 404 Page Not Found: Admin/withdrawals-requests.html
ERROR - 2019-06-16 09:44:35 --> 404 Page Not Found: Admin/withdrawals-requests.html
ERROR - 2019-06-16 09:45:12 --> 404 Page Not Found: Admin/withdrawals-requests.html
ERROR - 2019-06-16 09:45:17 --> 404 Page Not Found: Admin/withdrawals-requests.html
ERROR - 2019-06-16 10:40:47 --> 404 Page Not Found: Send_pass/index
ERROR - 2019-06-16 10:41:30 --> 404 Page Not Found: Check/index
ERROR - 2019-06-16 13:16:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-16 13:16:29 --> 404 Page Not Found: Admin/withdrawals-requests.html
ERROR - 2019-06-16 13:16:37 --> 404 Page Not Found: Admin/withdrawals-requests.html
ERROR - 2019-06-16 13:17:13 --> 404 Page Not Found: Admin/withdrawals-requests.html
ERROR - 2019-06-16 13:18:57 --> 404 Page Not Found: Admin/withdrawals-requests.html
ERROR - 2019-06-16 13:32:03 --> 404 Page Not Found: Admin/withdrawals-requests.html
ERROR - 2019-06-16 13:32:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-16 15:09:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-16 15:09:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-16 16:35:15 --> 404 Page Not Found: Who/index
ERROR - 2019-06-16 16:35:51 --> 404 Page Not Found: Who/index
ERROR - 2019-06-16 16:37:53 --> Query error: Unknown column 'email_key' in 'field list' - Invalid query: INSERT INTO `users` (`Name`, `Email`, `Username`, `Gender`, `Phone`, `State`, `Password`, `visit_count`, `DateRegistered`, `email_key`) VALUES ('SterlingWhite', 'SterlingWhite55@outlook.com', 'goodgood', 'Male', '21231412', 'Lagos', '0b4e7a0e5fe84ad35fb5f95b9ceeac79', 0, '2019-06-16 16:37:53', '1436d5e1f415992b0cf119856ab4b0a2')
ERROR - 2019-06-16 16:51:58 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.googlemail.com:465 (Network is unreachable) /home/pmbcjykk/public_html/pmb2/system/libraries/Email.php 2069
ERROR - 2019-06-16 16:57:06 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.googlemail.com:465 (Network is unreachable) /home/pmbcjykk/public_html/pmb2/system/libraries/Email.php 2069
ERROR - 2019-06-16 17:02:21 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.googlemail.com:587 (Network is unreachable) /home/pmbcjykk/public_html/pmb2/system/libraries/Email.php 2069
ERROR - 2019-06-16 17:05:33 --> Severity: Warning --> fsockopen(): unable to connect to smtp.gmail.com:587 (Network is unreachable) /home/pmbcjykk/public_html/pmb2/system/libraries/Email.php 2069
ERROR - 2019-06-16 17:12:37 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-16 17:12:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-16 17:13:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-16 17:14:53 --> Severity: Notice --> Undefined index: smtp_user /home/pmbcjykk/public_html/pmb2/application/controllers/Auth.php 134
ERROR - 2019-06-16 17:21:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-16 17:24:48 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2019-06-16 17:46:51 --> Severity: Notice --> Trying to get property 'email_key' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Auth.php 160
ERROR - 2019-06-16 17:46:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-16 22:08:32 --> 404 Page Not Found: Robotstxt/index
