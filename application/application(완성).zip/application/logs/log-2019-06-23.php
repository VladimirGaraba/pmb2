<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-23 00:52:29 --> 404 Page Not Found: Adstxt/index
ERROR - 2019-06-23 04:48:59 --> 404 Page Not Found: Adstxt/index
ERROR - 2019-06-23 04:48:59 --> 404 Page Not Found: Adstxt/index
ERROR - 2019-06-23 04:52:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-23 04:53:30 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-23 04:56:08 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-23 04:57:25 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-23 05:07:56 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-23 06:14:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-23 07:51:55 --> 404 Page Not Found: Pmbclubcom/index
ERROR - 2019-06-23 08:57:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-23 10:35:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-23 10:35:19 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-23 19:19:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-23 23:10:23 --> 404 Page Not Found: Robotstxt/index
