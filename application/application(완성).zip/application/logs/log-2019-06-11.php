<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-11 02:34:17 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 02:34:17 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 02:34:17 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 02:34:17 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 02:34:17 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 02:34:17 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 02:34:17 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 02:34:17 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 02:34:17 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 02:34:18 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 02:34:18 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 02:34:18 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 02:34:18 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 02:34:18 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 02:45:12 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 02:45:12 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 02:45:12 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 03:52:03 --> Severity: error --> Exception: Call to undefined function getUsersOnline() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 23
ERROR - 2019-06-11 03:53:04 --> Severity: error --> Exception: Call to undefined function ereg() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:53:05 --> Severity: error --> Exception: Call to undefined function ereg() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:53:06 --> Severity: error --> Exception: Call to undefined function ereg() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:53:06 --> Severity: error --> Exception: Call to undefined function ereg() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:53:07 --> Severity: error --> Exception: Call to undefined function ereg() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:53:07 --> Severity: error --> Exception: Call to undefined function ereg() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:53:08 --> Severity: error --> Exception: Call to undefined function ereg() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:53:08 --> Severity: error --> Exception: Call to undefined function ereg() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:53:08 --> Severity: error --> Exception: Call to undefined function ereg() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:53:08 --> Severity: error --> Exception: Call to undefined function ereg() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:53:09 --> Severity: error --> Exception: Call to undefined function ereg() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:14 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:14 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:14 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:14 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:14 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:14 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:45 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:45 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:45 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:45 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:45 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:45 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:46 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:46 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:46 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:46 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:46 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:46 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:46 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:46 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:46 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:46 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:46 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:46 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:47 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:48 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:48 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:48 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:48 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:48 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:48 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:48 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:48 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:48 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:48 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:48 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:48 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:54 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:54 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:54 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:54 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:54 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:54 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:55 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:55 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:55 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:55 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:55 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:55 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:55 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:55 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:55 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:55 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:55 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:55 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:56 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:56 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:56 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:56 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:56 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:56 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:56 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:56 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:56 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:56 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:56 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:56 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:56 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:56 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:56 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:56 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:56 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:56 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:56 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:56 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:56 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:56 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:56 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:56 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:57 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:57 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:57 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:57 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:57 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:57 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:57 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:57 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:57 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:57 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:57 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:57 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:57 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:57 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:57 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:57 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:57 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:57 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:57 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:57 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:57 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:57 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:57 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:57 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:58 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:58 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:58 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:58 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:58 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:58 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:58 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:58 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:58 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:58 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:58 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:58 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:58 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:58 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:58 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:58 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:58 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:56:58 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:05 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:05 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:05 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:05 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:05 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:05 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:05 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:05 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:05 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:05 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:05 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:05 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:05 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:05 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:05 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:05 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:05 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:05 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:05 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:05 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:05 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:05 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:05 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:05 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:06 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:06 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:06 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:06 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:06 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:06 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:06 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:06 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:06 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:06 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:06 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:09 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:09 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:09 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:09 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:09 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:09 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:09 --> Severity: Warning --> preg_match(): No ending delimiter '^' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:38 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:38 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:38 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:50 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:50 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:50 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:51 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:51 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:51 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:52 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:52 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:52 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:52 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:52 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:57:52 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:05 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 03:58:05 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 03:58:05 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 03:58:05 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 03:58:05 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 03:58:05 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 03:58:06 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 03:58:06 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 03:58:06 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 03:58:06 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 03:58:06 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 03:58:07 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:07 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:07 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:09 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:09 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:09 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:09 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:09 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:09 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:10 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:10 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:10 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:10 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:10 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:10 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:10 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:10 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:10 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:10 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:10 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:10 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:11 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:11 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:11 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:11 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:11 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:11 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:12 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 03:58:12 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 03:58:12 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 03:58:12 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 03:58:12 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 03:58:12 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 03:58:12 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 03:58:12 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 03:58:12 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 03:58:13 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 03:58:13 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 03:58:13 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 03:58:24 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:24 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:24 --> Severity: Warning --> preg_match(): No ending delimiter '%' found F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:54 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:54 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 03:58:54 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:18 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:18 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:18 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:19 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:19 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:19 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:20 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:20 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:20 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:20 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:20 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:20 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:21 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:21 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:21 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:21 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:21 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:21 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:21 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:21 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:21 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:21 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:21 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:21 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:22 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:22 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:22 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:22 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:22 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:22 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:22 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:22 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:22 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:23 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:23 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:23 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:23 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:23 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:23 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:24 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:24 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:24 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:24 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:24 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:24 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:32 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:32 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:32 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:34 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:34 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:34 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:35 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:35 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:35 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:57 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:03:57 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:03:57 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:03:57 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:03:57 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:03:57 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:03:57 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:03:57 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:03:57 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:03:57 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:03:59 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:59 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:03:59 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:04 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:04 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:04 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:04 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:04 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:04 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:04 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:04 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:04 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:05 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:05 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:05 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:05 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:05 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:05 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:05 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:05 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:05 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:05 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:05 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:05 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:05 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:05 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:05 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:05 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:05 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:05 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:06 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:06 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:06 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:06 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:06 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:06 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:06 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:06 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:06 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:06 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:06 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:06 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:06 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:06 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:06 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:07 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:07 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:07 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:07 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:07 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:07 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:08 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:08 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:08 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:08 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:08 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:08 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:08 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:08 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:08 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:08 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:08 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:08 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:08 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:08 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:08 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:08 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:08 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:09 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:10 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:10 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:10 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:10 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:10 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:10 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:10 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:10 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:10 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:10 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:10 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:10 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:10 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:10 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:10 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:10 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:10 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:10 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:10 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:10 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:10 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:11 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:11 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:11 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:11 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:11 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:11 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:12 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:12 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:12 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:14 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:14 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:14 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:14 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:14 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:14 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:14 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:14 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:14 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:15 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:15 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:15 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:15 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:15 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:15 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:15 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:15 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:15 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:15 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:15 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:15 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:15 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:15 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:15 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:18 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:18 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:18 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:18 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:18 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:18 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:19 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:19 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:19 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:19 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:19 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:19 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:19 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:19 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:19 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:20 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:20 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:20 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:20 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:20 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:20 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:20 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:20 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:20 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:20 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:20 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:21 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:21 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:21 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:21 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:21 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:21 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:04:21 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:04:21 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:21 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:04:39 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:39 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:04:39 --> Severity: Warning --> preg_match(): Delimiter must not be alphanumeric or backslash F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 128
ERROR - 2019-06-11 04:14:37 --> 404 Page Not Found: Aboutus/index
ERROR - 2019-06-11 04:15:31 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:15:31 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:15:31 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:15:31 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:15:31 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:15:35 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 04:15:35 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 04:15:35 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 04:21:25 --> Query error: Table 'test.ci_sessions' doesn't exist - Invalid query: SELECT 1
FROM `ci_sessions`
WHERE `id` = 'k2869l6tb9kn2han07ou6uc8c3a50hac'
ERROR - 2019-06-11 04:22:16 --> Query error: Unknown column 'data' in 'field list' - Invalid query: SELECT `data`
FROM `ci_sessions`
WHERE `id` = 'k2869l6tb9kn2han07ou6uc8c3a50hac'
ERROR - 2019-06-11 04:22:16 --> Severity: Warning --> session_write_close(): Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-06-11 04:22:16 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ) Unknown 0
ERROR - 2019-06-11 04:22:53 --> Query error: Unknown column 'ip_address' in 'field list' - Invalid query: INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k2869l6tb9kn2han07ou6uc8c3a50hac', '192.168.3.149', 1560226973, '__ci_last_regenerate|i:1560226973;')
ERROR - 2019-06-11 04:22:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Output.php:538) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Common.php 570
ERROR - 2019-06-11 04:22:53 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-06-11 04:22:53 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: ) Unknown 0
ERROR - 2019-06-11 04:22:55 --> Query error: Unknown column 'ip_address' in 'field list' - Invalid query: INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k2869l6tb9kn2han07ou6uc8c3a50hac', '192.168.3.149', 1560226975, '__ci_last_regenerate|i:1560226975;')
ERROR - 2019-06-11 04:22:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Output.php:538) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Common.php 570
ERROR - 2019-06-11 04:22:55 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-06-11 04:22:55 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: ) Unknown 0
ERROR - 2019-06-11 04:22:57 --> Query error: Unknown column 'ip_address' in 'field list' - Invalid query: INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k2869l6tb9kn2han07ou6uc8c3a50hac', '192.168.3.149', 1560226977, '__ci_last_regenerate|i:1560226977;')
ERROR - 2019-06-11 04:22:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Output.php:538) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Common.php 570
ERROR - 2019-06-11 04:22:57 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-06-11 04:22:57 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: ) Unknown 0
ERROR - 2019-06-11 05:11:26 --> 404 Page Not Found: Visitor/winners
ERROR - 2019-06-11 05:12:23 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:12:49 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:12:50 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:12:51 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:12:51 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:12:51 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:12:52 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:12:58 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:13:01 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:13:02 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:13:02 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:13:03 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:13:03 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:13:03 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:13:04 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:13:04 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:13:04 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:13:05 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:13:05 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:13:06 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:13:06 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:13:07 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:13:07 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:13:07 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:13:08 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:13:08 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:13:09 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:13:09 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:13:23 --> Severity: error --> Exception: F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\models/Visitor_Model.php exists, but doesn't declare class Visitor_Model F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\Loader.php 340
ERROR - 2019-06-11 05:13:24 --> Query error: Table 'test.site_log' doesn't exist - Invalid query: SELECT SUM(no_of_visits) as visits 
            FROM site_log 
            WHERE CURDATE()=DATE(access_date)
            LIMIT 1
ERROR - 2019-06-11 05:13:24 --> Query error: Table 'test.site_log' doesn't exist - Invalid query: SELECT SUM(no_of_visits) as visits 
            FROM site_log 
            WHERE CURDATE()=DATE(access_date)
            LIMIT 1
ERROR - 2019-06-11 05:13:25 --> Query error: Table 'test.site_log' doesn't exist - Invalid query: SELECT SUM(no_of_visits) as visits 
            FROM site_log 
            WHERE CURDATE()=DATE(access_date)
            LIMIT 1
ERROR - 2019-06-11 05:13:26 --> Query error: Table 'test.site_log' doesn't exist - Invalid query: SELECT SUM(no_of_visits) as visits 
            FROM site_log 
            WHERE CURDATE()=DATE(access_date)
            LIMIT 1
ERROR - 2019-06-11 05:52:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:52:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:52:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:52:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:52:34 --> Severity: Notice --> Undefined property: CI_Loader::$site_config F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:52:34 --> Severity: error --> Exception: Call to a member function generate_months() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:52:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:52:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:52:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:52:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:52:37 --> Severity: Notice --> Undefined property: CI_Loader::$site_config F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:52:38 --> Severity: error --> Exception: Call to a member function generate_months() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:52:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:52:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:52:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:52:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:52:39 --> Severity: Notice --> Undefined property: CI_Loader::$site_config F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:52:39 --> Severity: error --> Exception: Call to a member function generate_months() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:52:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:52:45 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:52:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:52:45 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:52:45 --> Severity: Notice --> Undefined property: CI_Loader::$site_config F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:52:45 --> Severity: error --> Exception: Call to a member function generate_months() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:52:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:52:46 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:52:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:52:46 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:52:46 --> Severity: Notice --> Undefined property: CI_Loader::$site_config F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:52:46 --> Severity: error --> Exception: Call to a member function generate_months() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:52:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:52:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:52:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:52:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:52:48 --> Severity: Notice --> Undefined property: CI_Loader::$site_config F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:52:48 --> Severity: error --> Exception: Call to a member function generate_months() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:52:48 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:48 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:48 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:48 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:48 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:48 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:48 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:52:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:52:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:52:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:52:57 --> Severity: Notice --> Undefined property: CI_Loader::$site_config F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:52:57 --> Severity: error --> Exception: Call to a member function generate_months() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:52:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:52:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:53:18 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:53:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:53:18 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:53:18 --> Severity: Notice --> Undefined property: CI_Loader::$site_config F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:53:18 --> Severity: error --> Exception: Call to a member function generate_months() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:53:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:53:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:53:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:53:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:53:25 --> Severity: Notice --> Undefined property: CI_Loader::$site_config F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:53:25 --> Severity: error --> Exception: Call to a member function generate_months() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:53:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:53:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:53:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:53:25 --> Severity: Notice --> Undefined property: CI_Loader::$site_config F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:53:25 --> Severity: error --> Exception: Call to a member function generate_months() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:53:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:53:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:53:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:53:26 --> Severity: Notice --> Undefined property: CI_Loader::$site_config F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:53:26 --> Severity: error --> Exception: Call to a member function generate_months() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:53:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:53:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:53:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:53:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:53:26 --> Severity: Notice --> Undefined property: CI_Loader::$site_config F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:53:26 --> Severity: error --> Exception: Call to a member function generate_months() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:53:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:53:27 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:53:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:53:27 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:53:27 --> Severity: Notice --> Undefined property: CI_Loader::$site_config F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:53:27 --> Severity: error --> Exception: Call to a member function generate_months() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 126
ERROR - 2019-06-11 05:53:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:53:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:01 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:01 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:01 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:01 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:01 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:01 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:01 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:01 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:01 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:01 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:01 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:02 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:02 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:02 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:02 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:31 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:31 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:31 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:31 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:31 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:31 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:31 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:31 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:31 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:31 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:31 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:31 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:31 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:31 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:32 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:32 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:32 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:32 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:33 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:33 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:33 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:33 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:33 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:33 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:33 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:33 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:34 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:40 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:40 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:40 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:40 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:40 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:40 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:40 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:40 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:40 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:40 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:40 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:40 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:43 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:43 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:43 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:43 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:43 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:43 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:43 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:43 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:43 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:43 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:43 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:43 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:43 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:44 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:44 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:44 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:44 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:44 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:44 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 05:58:45 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 05:58:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 05:58:45 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 05:58:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 05:58:45 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 05:58:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 05:58:45 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 05:58:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 05:58:45 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:17:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-06-11 06:17:42 --> Unable to connect to the database
ERROR - 2019-06-11 06:17:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-11 06:19:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:19:32 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:19:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:19:32 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:19:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:19:32 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:19:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:19:32 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:19:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:19:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:19:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:19:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:19:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:19:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:19:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:19:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:19:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:19:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:19:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:19:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:19:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:19:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:19:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:19:48 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:19:48 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:19:48 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:19:48 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:19:48 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:19:48 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:22:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:22:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:22:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:22:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:22:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:22:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:22:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:22:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:22:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:22:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:22:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:22:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:22:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:22:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:24:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:24:46 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:24:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:24:46 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:24:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:24:46 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:24:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:24:46 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:24:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:24:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:24:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:24:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:24:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:24:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:25:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:25:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:25:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:25:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:25:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:25:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:25:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:25:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:25:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:25:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:25:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:25:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:25:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:25:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:25:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-06-11 06:29:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:29:55 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:29:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:29:55 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:29:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:29:55 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:29:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:29:55 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:29:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:29:56 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:29:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:29:56 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:29:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:29:56 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:29:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:29:56 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:29:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:29:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:29:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:29:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:29:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:29:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:29:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:29:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:29:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:29:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:29:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:29:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:29:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:29:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:29:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:29:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:29:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:29:58 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:29:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:29:58 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:29:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:29:58 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:29:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:29:58 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:29:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:29:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:29:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:29:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:29:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:29:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:29:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:29:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:29:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:29:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:29:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:29:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:29:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:29:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:29:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:29:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:30:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:30:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:30:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:30:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:30:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:30:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:30:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:30:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:30:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:30:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:30:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:30:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:30:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:30:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:30:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:30:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:30:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:30:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:30:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:30:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:30:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:30:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:30:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:30:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:30:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:30:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:30:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:30:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:30:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:30:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:30:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:30:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:30:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:30:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:30:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:30:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:30:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:30:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:30:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:30:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:30:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:30:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:30:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:30:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:30:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:30:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:30:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:30:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:30:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:30:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:30:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:32:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:32:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:32:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:32:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:32:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:32:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:32:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:32:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:33:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:33:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:33:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:33:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:33:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:33:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:33:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:33:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:33:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:33:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:33:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:33:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:33:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:33:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:33:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:33:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:33:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:33:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:33:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:33:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:33:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:33:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:33:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:33:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:33:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:33:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:33:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:33:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:33:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:33:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:33:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:33:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:33:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:33:45 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:33:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:33:45 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:33:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:33:45 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:33:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:33:45 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:33 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:33 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:33 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:33 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:38 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:38 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:38 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:38 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:38 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:38 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:38 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:38 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:40 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:43 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:43 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:43 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:43 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:43 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:43 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:43 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:43 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:43 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:43 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:45 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:45 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:45 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:46 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:46 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:46 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:46 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:46 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:47 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:39:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:39:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:39:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:39:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:47:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:47:21 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:47:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:47:21 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:47:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:47:21 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:47:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:47:21 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:47:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:47:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:54:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:54:20 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:54:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:54:20 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:54:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:54:20 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:54:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:54:20 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:54:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:54:21 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:54:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:54:21 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:54:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:54:21 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:54:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:54:21 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:54:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:54:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:54:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:54:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:54:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:54:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:54:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:54:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:54:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:54:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:54:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:54:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:54:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:54:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:54:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:54:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:54:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:54:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:54:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:54:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:54:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:54:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:54:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:54:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:54:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:54:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:54:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:54:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:54:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:54:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:54:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:54:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:54:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:54:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:54:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:54:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:54:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:54:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:54:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:54:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:54:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:54:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:54:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:54:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:54:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:54:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:54:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:54:28 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:54:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:54:28 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:54:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:54:28 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:54:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:54:28 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:54:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:54:28 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:54:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:54:28 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:54:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:54:28 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:54:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:54:28 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:54:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:54:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:54:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:54:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:54:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:54:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:54:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:54:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:54:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:54:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:54:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:54:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:54:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:54:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:54:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:54:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:54:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:54:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:54:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:54:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:54:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:54:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:54:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:54:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:54:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:54:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:54:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:54:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:54:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:54:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:54:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:54:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:54:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:54:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 06:54:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 06:54:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 06:54:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 06:54:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 06:54:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 06:54:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 06:54:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 06:59:44 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Visitor.php 21
ERROR - 2019-06-11 06:59:45 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Visitor.php 21
ERROR - 2019-06-11 07:00:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:00:51 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 07:00:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 07:00:51 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:00:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 07:00:51 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:00:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 07:00:51 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:00:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:00:52 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 07:00:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 07:00:52 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:00:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 07:00:52 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:00:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 07:00:52 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:00:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:00:52 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 07:00:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 07:00:52 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:00:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 07:00:52 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:00:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 07:00:52 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:00:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:00:53 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 07:00:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 07:00:53 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:00:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 07:00:53 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:00:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 07:00:53 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:00:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:00:53 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 07:00:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 07:00:53 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:00:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 07:00:53 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:00:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 07:00:53 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:00:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:00:54 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 07:00:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 07:00:54 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:00:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 07:00:54 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:00:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 07:00:54 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:00:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:00:54 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 07:00:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 07:00:54 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:00:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 07:00:54 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:00:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 07:00:54 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:00:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:00:56 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 07:00:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 07:00:56 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:00:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 07:00:56 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:00:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 07:00:56 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:00:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:00:56 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 07:00:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 07:00:56 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:00:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 07:00:56 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:00:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 07:00:56 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:00:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:00:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 07:00:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 07:00:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:00:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 07:00:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:00:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 07:00:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:00:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:00:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 07:00:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 07:00:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:00:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 07:00:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:00:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 07:00:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:07:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:07:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 07:07:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 07:07:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:07:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 07:07:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:07:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 07:07:23 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:07:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:07:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 07:07:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 07:07:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:07:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 07:07:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:07:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 07:07:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:07:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:07:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 07:07:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 07:07:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:07:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 07:07:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:07:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 07:07:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:07:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:07:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 07:07:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 07:07:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:07:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 07:07:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:07:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 07:07:24 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 07:07:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 36
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 75
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 151
ERROR - 2019-06-11 07:07:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:07:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 191
ERROR - 2019-06-11 07:07:27 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:15 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:15 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:15 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:15 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:27 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:27 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:27 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:27 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:27 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:27 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:28 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:28 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:28 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:28 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:31 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:32 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:32 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:32 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:32 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:32 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:32 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:32 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:32 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:33 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:33 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:33 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:33 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:33 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:33 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:33 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:33 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:33 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:33 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:33 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:33 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:36 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:37 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:38 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:38 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:38 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:38 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:38 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:38 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:38 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:38 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:38 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:38 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:38 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:38 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:09:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:09:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:09:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:09:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:09:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:09:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:09:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:09:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:10:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:10:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:10:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:10:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:10:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:10:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:10:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:10:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:10:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:10:46 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:10:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:10:46 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:10:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:10:46 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:10:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:10:46 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:10:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:10:47 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:10:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:10:47 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:10:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:10:47 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:10:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:10:47 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:10:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:10:47 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:10:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:10:47 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:10:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:10:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:10:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:10:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:10:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:10:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:10:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:10:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:10:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:10:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:10:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:10:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:10:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:10:49 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:10:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:10:49 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:10:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:10:49 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:10:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:10:49 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:11:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:11:50 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:11:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:11:50 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:11:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:11:50 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:11:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:11:50 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:11:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:11:51 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:11:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:11:51 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:11:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:11:51 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:11:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:11:51 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:11:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:11:52 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:11:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:11:52 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:11:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:11:52 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:11:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:11:52 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:11:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:11:53 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:11:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:11:53 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:11:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:11:53 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:11:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:11:53 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:11:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:11:54 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:11:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:11:54 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:11:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:11:54 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:11:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:11:54 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:11:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:11:55 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:11:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:11:55 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:11:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:11:55 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:11:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:11:55 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:11:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:11:55 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:11:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:11:55 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:11:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:11:55 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:11:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:11:55 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:11:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:11:55 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:11:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:11:55 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:11:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:11:55 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:11:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:11:55 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:11:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:11:56 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:11:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:11:56 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:11:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:11:56 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:11:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:11:56 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:11:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:11:56 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:11:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:11:56 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:11:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:11:56 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:11:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:11:56 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:11:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:11:56 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:11:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:11:56 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:11:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:11:56 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:11:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:11:56 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:11:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:11:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:11:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:11:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:11:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:11:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:11:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:11:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:11:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:11:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:11:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:11:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:11:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:11:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:11:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:11:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:11:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:11:58 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:11:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:11:58 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:11:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:11:58 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:11:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:11:58 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:11:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:11:58 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:11:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:11:58 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:11:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:11:58 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:11:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:11:58 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:11:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:11:58 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:11:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:11:58 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:11:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:11:58 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:11:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:11:58 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:11:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:11:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:11:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:11:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:11:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:11:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:11:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:11:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:11:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:11:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:11:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:11:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:12:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:12:01 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:12:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:12:01 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:12:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:12:01 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:12:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:12:01 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:12:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:12:01 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:12:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:12:01 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:12:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:12:01 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:12:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:12:01 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:12:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:12:02 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:12:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:12:02 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:12:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:12:02 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:12:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:12:02 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:12:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:12:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:12:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:12:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:12:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:12:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:12:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:12:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:12:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:12:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:12:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:12:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:14:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:14:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:14:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:14:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:14:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:14:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:14:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:14:26 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:14:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:14:27 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:14:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:14:27 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:14:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:14:27 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:14:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:14:27 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:15:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:15:58 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:15:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:15:58 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:15:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:15:58 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:15:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:15:58 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:15:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:15:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:15:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:15:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:15:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:15:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:15:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:15:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:01 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:01 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:01 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:01 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:01 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:01 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:01 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:01 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:02 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:02 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:02 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:02 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:02 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:02 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:02 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:02 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:03 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:04 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:09 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:10 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:10 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:10 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:10 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:10 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:10 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:10 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:10 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:11 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:11 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:11 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:11 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:12 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:12 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:12 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:12 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:12 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:12 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:12 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:12 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:13 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:13 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:13 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:13 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:14 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:14 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:14 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:14 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:14 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:14 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:14 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:14 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:15 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:15 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:15 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:15 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:16 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:16 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:16 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:16 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:16 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:16 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:16 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:16 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:16 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:17 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:17 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:17 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 07:16:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 07:16:17 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 07:16:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 07:16:17 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 07:16:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 07:16:17 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 07:16:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 07:16:17 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 10:46:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 10:46:46 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 10:46:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 10:46:46 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 10:46:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 10:46:46 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 10:46:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 10:46:46 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 10:46:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 10:46:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 10:46:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 10:46:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 10:46:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 10:46:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 10:46:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 10:46:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 10:46:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 10:46:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 10:46:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 10:46:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 10:46:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 10:46:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 10:46:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 10:46:48 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 10:46:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 10:46:49 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 10:46:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 10:46:49 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 10:46:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 10:46:49 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 10:46:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 10:46:49 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 10:46:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 10:46:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 10:46:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 10:46:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 10:46:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 10:46:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 10:46:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 10:46:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 10:46:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 10:46:59 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 10:47:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 10:47:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 10:47:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 10:47:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 10:47:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 10:47:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 10:47:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 10:47:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 10:47:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 10:47:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 10:47:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 10:47:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 10:47:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 10:47:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 10:47:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 10:47:01 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 10:47:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 10:47:01 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 10:47:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 10:47:01 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 10:47:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 10:47:01 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 12:08:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 35
ERROR - 2019-06-11 12:08:18 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 37
ERROR - 2019-06-11 12:08:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 76
ERROR - 2019-06-11 12:08:18 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 77
ERROR - 2019-06-11 12:08:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 152
ERROR - 2019-06-11 12:08:18 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 153
ERROR - 2019-06-11 12:08:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 192
ERROR - 2019-06-11 12:08:18 --> Severity: Warning --> Invalid argument supplied for foreach() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\visitor.php 193
ERROR - 2019-06-11 12:19:45 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\user-templates\header.php 5
ERROR - 2019-06-11 12:19:47 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-11 12:20:12 --> 404 Page Not Found: Admin/index
ERROR - 2019-06-11 13:32:18 --> Severity: Notice --> session_start(): A session had already been started - ignoring F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 123
ERROR - 2019-06-11 13:32:18 --> Severity: Notice --> Undefined variable: count F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 139
ERROR - 2019-06-11 13:34:30 --> Severity: Notice --> Undefined variable: count F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 153
ERROR - 2019-06-11 13:34:30 --> Severity: Notice --> Undefined variable: count F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 153
ERROR - 2019-06-11 13:34:33 --> Severity: Notice --> Undefined variable: count F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 153
ERROR - 2019-06-11 13:34:56 --> Severity: Notice --> Undefined variable: count F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 153
ERROR - 2019-06-11 13:34:57 --> Severity: Notice --> Undefined variable: count F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 153
ERROR - 2019-06-11 13:35:01 --> Severity: Notice --> Undefined variable: count F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 153
ERROR - 2019-06-11 13:35:02 --> Severity: Notice --> Undefined variable: count F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 153
ERROR - 2019-06-11 13:35:04 --> Severity: Notice --> Undefined variable: count F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 153
ERROR - 2019-06-11 15:54:44 --> Severity: Warning --> A non-numeric value encountered F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 41
ERROR - 2019-06-11 15:54:44 --> Severity: Warning --> A non-numeric value encountered F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 41
ERROR - 2019-06-11 15:54:47 --> Severity: Warning --> A non-numeric value encountered F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 41
ERROR - 2019-06-11 15:54:47 --> Severity: Warning --> A non-numeric value encountered F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 41
ERROR - 2019-06-11 15:54:48 --> Severity: Warning --> A non-numeric value encountered F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 41
ERROR - 2019-06-11 15:54:48 --> Severity: Warning --> A non-numeric value encountered F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 41
ERROR - 2019-06-11 15:58:27 --> Severity: Warning --> A non-numeric value encountered F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 41
ERROR - 2019-06-11 15:58:27 --> Severity: Warning --> A non-numeric value encountered F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 41
ERROR - 2019-06-11 16:26:19 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 16:26:19 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 16:26:19 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 16:26:19 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 16:26:19 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 16:26:22 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 16:26:22 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 16:26:22 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 16:26:22 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 16:26:22 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 16:26:24 --> 404 Page Not Found: Js/jquery.js
ERROR - 2019-06-11 16:26:24 --> 404 Page Not Found: Js/plugins.js
ERROR - 2019-06-11 16:26:24 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 16:26:24 --> 404 Page Not Found: Js/functions.js
ERROR - 2019-06-11 16:46:26 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:46:27 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:46:28 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:46:29 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:46:47 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:46:47 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:46:48 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:46:48 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:46:50 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:46:51 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:46:52 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:46:53 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:46:53 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:46:55 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:46:56 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:03 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:04 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:05 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:06 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:07 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:07 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:08 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:08 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:09 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:10 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:11 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:12 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:14 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:14 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:15 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:15 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:15 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:15 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:16 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:16 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:16 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:16 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:17 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:18 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:18 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:18 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:18 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:20 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:20 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:21 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:21 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:21 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:21 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:22 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:23 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:24 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:24 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 16:47:25 --> 404 Page Not Found: Front/js
ERROR - 2019-06-11 18:53:33 --> Severity: Notice --> Undefined index: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 39
ERROR - 2019-06-11 18:53:33 --> Severity: Notice --> Undefined index: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 40
ERROR - 2019-06-11 18:53:33 --> Severity: Notice --> Undefined index: phone F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 41
ERROR - 2019-06-11 18:53:33 --> Severity: Notice --> Undefined index: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 43
ERROR - 2019-06-11 18:54:22 --> Severity: Notice --> Undefined index: name F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 39
ERROR - 2019-06-11 18:54:22 --> Severity: Notice --> Undefined index: email F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 40
ERROR - 2019-06-11 18:54:22 --> Severity: Notice --> Undefined index: phone F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 41
ERROR - 2019-06-11 18:54:22 --> Severity: Notice --> Undefined index: amount F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 43
ERROR - 2019-06-11 19:01:44 --> Severity: error --> Exception: Too few arguments to function Pages::paystack(), 0 passed in F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\CodeIgniter.php on line 532 and exactly 1 expected F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 38
ERROR - 2019-06-11 19:01:53 --> Severity: error --> Exception: Too few arguments to function Pages::paystack(), 0 passed in F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\CodeIgniter.php on line 532 and exactly 1 expected F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 38
ERROR - 2019-06-11 19:02:34 --> Severity: error --> Exception: Too few arguments to function Pages::paystack(), 0 passed in F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\CodeIgniter.php on line 532 and exactly 1 expected F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 38
ERROR - 2019-06-11 19:02:47 --> Severity: Notice --> Undefined variable: success F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 42
ERROR - 2019-06-11 19:05:11 --> Severity: Notice --> Undefined variable: success F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 42
ERROR - 2019-06-11 19:05:51 --> Severity: Warning --> json_encode() expects at least 1 parameter, 0 given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 42
ERROR - 2019-06-11 19:06:16 --> Severity: Warning --> json_encode() expects at least 1 parameter, 0 given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 42
ERROR - 2019-06-11 19:07:19 --> Severity: error --> Exception: Too few arguments to function Pages::paystack(), 0 passed in F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\CodeIgniter.php on line 532 and exactly 1 expected F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 38
ERROR - 2019-06-11 19:07:35 --> Severity: error --> Exception: Too few arguments to function Pages::paystack(), 0 passed in F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\core\CodeIgniter.php on line 532 and exactly 1 expected F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 38
ERROR - 2019-06-11 19:30:51 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 39
ERROR - 2019-06-11 19:30:55 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 39
ERROR - 2019-06-11 20:48:20 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 39
ERROR - 2019-06-11 20:48:57 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 39
ERROR - 2019-06-11 20:48:59 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 39
ERROR - 2019-06-11 20:49:11 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 39
ERROR - 2019-06-11 20:49:13 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 39
ERROR - 2019-06-11 20:49:14 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 39
ERROR - 2019-06-11 20:49:15 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 39
ERROR - 2019-06-11 20:49:33 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 39
ERROR - 2019-06-11 20:50:20 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 39
ERROR - 2019-06-11 20:50:20 --> Severity: Notice --> Undefined variable: request F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 40
ERROR - 2019-06-11 20:50:20 --> Severity: error --> Exception: Call to a member function json_encode() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 40
ERROR - 2019-06-11 20:50:57 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 39
ERROR - 2019-06-11 20:50:57 --> Severity: Notice --> Undefined variable: request F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 40
ERROR - 2019-06-11 20:50:57 --> Severity: error --> Exception: Call to a member function json_encode() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 40
ERROR - 2019-06-11 20:51:10 --> Severity: Notice --> Array to string conversion F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 39
ERROR - 2019-06-11 20:51:10 --> Severity: Notice --> Undefined variable: request F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 40
ERROR - 2019-06-11 20:51:10 --> Severity: error --> Exception: Call to a member function json_encode() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 40
ERROR - 2019-06-11 20:51:27 --> Severity: Notice --> Undefined variable: request F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 40
ERROR - 2019-06-11 20:51:27 --> Severity: error --> Exception: Call to a member function json_encode() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 40
ERROR - 2019-06-11 20:51:47 --> Severity: Notice --> Undefined variable: request F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 40
ERROR - 2019-06-11 20:51:47 --> Severity: error --> Exception: Call to a member function json_encode() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 40
ERROR - 2019-06-11 20:51:51 --> Severity: Notice --> Undefined variable: request F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 40
ERROR - 2019-06-11 20:51:51 --> Severity: error --> Exception: Call to a member function json_encode() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 40
ERROR - 2019-06-11 20:51:55 --> Severity: Notice --> Undefined variable: request F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 40
ERROR - 2019-06-11 20:51:55 --> Severity: error --> Exception: Call to a member function json_encode() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 40
ERROR - 2019-06-11 20:52:23 --> Severity: Notice --> Undefined variable: request F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 40
ERROR - 2019-06-11 20:52:23 --> Severity: error --> Exception: Call to a member function json_encode() on null F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 40
ERROR - 2019-06-11 20:52:51 --> Severity: Notice --> Undefined variable: request F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 40
ERROR - 2019-06-11 20:52:51 --> Severity: Notice --> Trying to get property 'JSON' of non-object F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 40
ERROR - 2019-06-11 20:52:51 --> Severity: error --> Exception: Call to undefined function parse() F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 40
ERROR - 2019-06-11 20:54:03 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 40
ERROR - 2019-06-11 20:54:51 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 40
ERROR - 2019-06-11 20:55:33 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 41
ERROR - 2019-06-11 20:56:32 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 41
ERROR - 2019-06-11 20:57:11 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 41
ERROR - 2019-06-11 20:58:01 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 41
ERROR - 2019-06-11 21:05:39 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 41
ERROR - 2019-06-11 21:06:29 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 41
ERROR - 2019-06-11 21:16:05 --> Severity: Notice --> Trying to get property 'name' of non-object F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 40
