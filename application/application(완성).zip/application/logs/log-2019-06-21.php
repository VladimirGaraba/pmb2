<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-21 02:53:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-21 07:39:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-21 07:45:25 --> Severity: Notice --> Undefined property: stdClass::$visit_count /home/pmbcjykk/public_html/pmb2/application/models/User_Model.php 102
ERROR - 2019-06-21 07:45:26 --> Severity: Notice --> Trying to get property 'Amount' of non-object /home/pmbcjykk/public_html/pmb2/application/models/Deposit_M.php 57
ERROR - 2019-06-21 07:48:22 --> Severity: Notice --> Trying to get property 'Amount' of non-object /home/pmbcjykk/public_html/pmb2/application/models/Deposit_M.php 57
ERROR - 2019-06-21 07:48:25 --> Severity: Notice --> Trying to get property 'Amount' of non-object /home/pmbcjykk/public_html/pmb2/application/models/Deposit_M.php 57
ERROR - 2019-06-21 07:48:29 --> Severity: Notice --> Trying to get property 'Amount' of non-object /home/pmbcjykk/public_html/pmb2/application/models/Deposit_M.php 57
ERROR - 2019-06-21 07:48:33 --> Severity: Notice --> Trying to get property 'Amount' of non-object /home/pmbcjykk/public_html/pmb2/application/models/Deposit_M.php 57
ERROR - 2019-06-21 07:49:10 --> Severity: Notice --> Undefined property: stdClass::$visit_count /home/pmbcjykk/public_html/pmb2/application/models/User_Model.php 102
ERROR - 2019-06-21 07:49:35 --> 404 Page Not Found: Admin/index
ERROR - 2019-06-21 07:55:23 --> 404 Page Not Found: Admin/login
ERROR - 2019-06-21 07:55:26 --> 404 Page Not Found: Admin/login
ERROR - 2019-06-21 07:58:10 --> 404 Page Not Found: Admin/login
ERROR - 2019-06-21 08:19:13 --> Severity: Notice --> Trying to get property 'Amount' of non-object /home/pmbcjykk/public_html/pmb2/application/models/Deposit_M.php 57
ERROR - 2019-06-21 08:19:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-21 08:46:21 --> Severity: Notice --> Trying to get property 'Amount' of non-object /home/pmbcjykk/public_html/pmb2/application/models/Deposit_M.php 57
ERROR - 2019-06-21 08:46:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-21 08:47:27 --> 404 Page Not Found: User/user
ERROR - 2019-06-21 09:12:46 --> 404 Page Not Found: Admin/add-deposits.html
ERROR - 2019-06-21 09:23:20 --> 404 Page Not Found: User/add-deposits.html
ERROR - 2019-06-21 09:28:51 --> Severity: Notice --> Undefined variable: category /home/pmbcjykk/public_html/pmb2/application/views/pages/user/play-lottery.php 43
ERROR - 2019-06-21 09:28:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pmbcjykk/public_html/pmb2/application/views/pages/user/play-lottery.php 43
ERROR - 2019-06-21 10:51:29 --> Severity: Notice --> Undefined property: Users::$upload /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 194
ERROR - 2019-06-21 10:51:29 --> Severity: error --> Exception: Call to a member function initialize() on null /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 194
ERROR - 2019-06-21 11:01:22 --> Severity: error --> Exception: syntax error, unexpected ''pagination'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' /home/pmbcjykk/public_html/pmb2/application/config/autoload.php 61
ERROR - 2019-06-21 11:01:54 --> Severity: Notice --> Undefined variable: image /home/pmbcjykk/public_html/pmb2/application/views/user-templates/header.php 106
ERROR - 2019-06-21 11:08:08 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:08:58 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:10:52 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:12:46 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:12:49 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:14:28 --> Severity: error --> Exception: syntax error, unexpected '<' /home/pmbcjykk/public_html/pmb2/application/views/user-templates/header.php 108
ERROR - 2019-06-21 11:15:05 --> Severity: error --> Exception: syntax error, unexpected 'front' (T_STRING), expecting ',' or ')' /home/pmbcjykk/public_html/pmb2/application/views/user-templates/header.php 108
ERROR - 2019-06-21 11:16:58 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:17:53 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:21:08 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:23:27 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file /home/pmbcjykk/public_html/pmb2/application/views/user-templates/header.php 107
ERROR - 2019-06-21 11:25:54 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file /home/pmbcjykk/public_html/pmb2/application/views/user-templates/header.php 107
ERROR - 2019-06-21 11:26:00 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file /home/pmbcjykk/public_html/pmb2/application/views/user-templates/header.php 107
ERROR - 2019-06-21 11:27:12 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file /home/pmbcjykk/public_html/pmb2/application/views/user-templates/header.php 107
ERROR - 2019-06-21 11:33:07 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:33:41 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2019-06-21 11:34:23 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:35:41 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:36:10 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:36:14 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:37:23 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:37:24 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:37:30 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:37:32 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:40:38 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:40:46 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:41:13 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:41:15 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:41:18 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:41:21 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:41:23 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:41:25 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:41:34 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:43:58 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:44:02 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:44:05 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:44:20 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:44:22 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:44:24 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:44:28 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:44:29 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:45:44 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:45:58 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:45:59 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:46:56 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:49:52 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:49:56 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:50:11 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:51:43 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:52:01 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:58:46 --> Severity: Notice --> Undefined variable: id /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:46 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:47 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:58:48 --> Severity: Notice --> Undefined variable: id /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:48 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:49 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:58:50 --> Severity: Notice --> Undefined variable: id /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:50 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:51 --> Severity: Notice --> Undefined variable: id /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:51 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:51 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:58:51 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:58:52 --> Severity: Notice --> Undefined variable: id /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:52 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:52 --> Severity: Notice --> Undefined variable: id /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:52 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:53 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:58:53 --> Severity: Notice --> Undefined variable: id /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:53 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:53 --> Severity: Notice --> Undefined variable: id /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:53 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:54 --> Severity: Notice --> Undefined variable: id /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:54 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:54 --> Severity: Notice --> Undefined variable: id /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:54 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:55 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:58:55 --> Severity: Notice --> Undefined variable: id /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:55 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:56 --> Severity: Notice --> Undefined variable: id /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:56 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:56 --> Severity: Notice --> Undefined variable: id /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:56 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:56 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:58:57 --> Severity: Notice --> Undefined variable: id /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:57 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:57 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:58:57 --> Severity: Notice --> Undefined variable: id /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:57 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:58 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:58:59 --> Severity: Notice --> Undefined variable: id /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:59 --> Severity: Notice --> Trying to get property 'Picture' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 173
ERROR - 2019-06-21 11:58:59 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:58:59 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 11:59:38 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:00:12 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:00:41 --> Severity: Warning --> unlink(): http does not allow unlinking /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 199
ERROR - 2019-06-21 12:00:44 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:05:30 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:05:32 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:05:35 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:06:36 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:07:50 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:07:53 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:07:56 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:08:00 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:08:41 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:10:44 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:13:39 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:13:40 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:13:40 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:13:43 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:13:57 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:16:13 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:17:09 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:18:06 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:18:49 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:19:03 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:20:25 --> Severity: error --> Exception: Call to undefined function delete_files() /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 195
ERROR - 2019-06-21 12:23:04 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:23:06 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:23:24 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:25:44 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:25:46 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:25:48 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:25:49 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:27:51 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:28:08 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:28:51 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:28:53 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:29:07 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:34:29 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:34:31 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:34:43 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:34:53 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:35:02 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:35:38 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:35:41 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:35:54 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:53:21 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:53:24 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:54:52 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:54:54 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:55:10 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:56:04 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:56:06 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:56:20 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:57:09 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:57:11 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 12:57:49 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-21 16:31:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-21 16:31:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-21 16:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-21 16:31:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-21 16:31:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-21 21:47:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-21 22:22:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-21 22:22:44 --> 404 Page Not Found: Demo/images
