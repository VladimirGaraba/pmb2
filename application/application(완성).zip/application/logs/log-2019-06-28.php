<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-28 01:25:24 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2019-06-28 02:05:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-28 04:25:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-28 04:32:33 --> 404 Page Not Found: Admin/navbar-elements.html
ERROR - 2019-06-28 04:32:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-28 04:33:06 --> 404 Page Not Found: Admin/withdrawals-requests.html
ERROR - 2019-06-28 04:43:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-28 10:25:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-28 10:25:25 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-28 10:31:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-28 10:40:18 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-28 10:48:38 --> Severity: Notice --> Undefined variable: id /home/pmbcjykk/public_html/pmb2/application/models/User_Model.php 50
ERROR - 2019-06-28 11:00:05 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-28 11:00:05 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-28 11:00:05 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-28 11:00:05 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-28 12:12:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-28 14:06:43 --> Severity: Notice --> Undefined property: stdClass::$Wallet /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 19
ERROR - 2019-06-28 14:06:51 --> Severity: Notice --> Undefined property: stdClass::$Wallet /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 19
ERROR - 2019-06-28 14:07:04 --> Query error: Unknown column 't1.Name' in 'field list' - Invalid query: SELECT t1.Name, t1.Title, t1.TicketNumber, t1.Message, t1.Date, users.Picture FROM testimonials AS t1 LEFT JOIN `users` ON t1.Name = users.Name
ERROR - 2019-06-28 14:13:15 --> Severity: Notice --> Undefined property: stdClass::$Wallet /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 19
ERROR - 2019-06-28 14:13:16 --> Severity: Notice --> Undefined property: stdClass::$Wallet /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 19
ERROR - 2019-06-28 14:13:17 --> Severity: Notice --> Undefined property: stdClass::$Wallet /home/pmbcjykk/public_html/pmb2/application/controllers/Users.php 19
ERROR - 2019-06-28 14:13:19 --> Query error: Unknown column 't1.Name' in 'field list' - Invalid query: SELECT t1.Name, t1.Title, t1.TicketNumber, t1.Message, t1.Date, users.Picture FROM testimonials AS t1 LEFT JOIN `users` ON t1.Name = users.Name
ERROR - 2019-06-28 14:13:21 --> Query error: Unknown column 't1.Name' in 'field list' - Invalid query: SELECT t1.Name, t1.Title, t1.TicketNumber, t1.Message, t1.Date, users.Picture FROM testimonials AS t1 LEFT JOIN `users` ON t1.Name = users.Name
ERROR - 2019-06-28 21:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-28 21:25:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-28 21:25:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-28 21:25:58 --> 404 Page Not Found: Robotstxt/index
