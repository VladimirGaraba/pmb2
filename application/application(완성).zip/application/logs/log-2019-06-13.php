<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-13 06:10:25 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 36
ERROR - 2019-06-13 06:10:53 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 36
ERROR - 2019-06-13 06:11:16 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 36
ERROR - 2019-06-13 06:52:02 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-13 06:52:02 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-13 06:52:03 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-13 06:52:03 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-13 06:52:04 --> Severity: Warning --> mkdir(): Invalid path F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2019-06-13 06:52:04 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2019-06-13 06:57:31 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 08:08:28 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 08:08:31 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\user-templates\header.php 5
ERROR - 2019-06-13 08:08:33 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 08:46:43 --> Severity: error --> Exception: syntax error, unexpected ''.jpg'' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\pages\home.php 8
ERROR - 2019-06-13 09:20:01 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 09:20:02 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 09:20:06 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 09:20:20 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 09:20:21 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 09:20:23 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 09:20:30 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 10:52:43 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 10:52:46 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\user-templates\header.php 5
ERROR - 2019-06-13 10:52:47 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-13 10:58:16 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Users_Dashboard.php 13
ERROR - 2019-06-13 10:58:36 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-13 11:03:45 --> 404 Page Not Found: Admin/index
ERROR - 2019-06-13 11:04:40 --> 404 Page Not Found: Admin/add-deposit.html
ERROR - 2019-06-13 11:17:20 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 11:22:12 --> Severity: error --> Exception: syntax error, unexpected 'unset' (T_UNSET) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 151
ERROR - 2019-06-13 11:22:15 --> Severity: error --> Exception: syntax error, unexpected 'unset' (T_UNSET) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 151
ERROR - 2019-06-13 12:56:47 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 12:56:49 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 12:57:03 --> 404 Page Not Found: Users_dashboard/dashboard
ERROR - 2019-06-13 12:57:12 --> 404 Page Not Found: Admins_dashboard/payment-profile
ERROR - 2019-06-13 12:57:19 --> 404 Page Not Found: Admins_dashboard/play-lottery
ERROR - 2019-06-13 13:32:06 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 15:24:04 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 15:32:14 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 15:32:16 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 15:32:17 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 15:34:31 --> 404 Page Not Found: Use/index
ERROR - 2019-06-13 15:35:01 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 15:53:21 --> Severity: error --> Exception: syntax error, unexpected '{' F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 52
ERROR - 2019-06-13 15:53:24 --> Severity: error --> Exception: syntax error, unexpected '{' F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 52
ERROR - 2019-06-13 15:53:43 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 52
ERROR - 2019-06-13 15:53:45 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 52
ERROR - 2019-06-13 15:53:46 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 52
ERROR - 2019-06-13 15:56:45 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 15:56:52 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 15:56:57 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 16:20:14 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 16:20:25 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 16:20:36 --> 404 Page Not Found: Admins_dashboard/play-lottery
ERROR - 2019-06-13 16:43:00 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-13 16:43:09 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-13 17:20:20 --> Severity: error --> Exception: syntax error, unexpected ';' F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\controllers\Pages.php 148
ERROR - 2019-06-13 17:28:55 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 17:28:58 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-13 17:29:02 --> Severity: Notice --> Undefined variable: title F:\IZ-WAMP\httpd-2.4.39-win64-VC15\htdocs\pmb2\application\views\templates\header.php 29
ERROR - 2019-06-13 18:24:05 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-13 18:24:08 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-13 18:35:03 --> 404 Page Not Found: Withdrawals/index
ERROR - 2019-06-13 18:37:08 --> 404 Page Not Found: Withdrawals/index
ERROR - 2019-06-13 18:37:16 --> 404 Page Not Found: Withdrawals/index
ERROR - 2019-06-13 18:37:16 --> 404 Page Not Found: Withdrawals/index
ERROR - 2019-06-13 18:37:40 --> 404 Page Not Found: Withdrawals/index
ERROR - 2019-06-13 18:50:03 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-13 18:50:04 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-13 18:50:07 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-13 18:50:16 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-13 18:51:46 --> 404 Page Not Found: User/request-withdrawal.html
ERROR - 2019-06-13 18:51:55 --> 404 Page Not Found: User/request-withdrawal.html
ERROR - 2019-06-13 18:52:03 --> 404 Page Not Found: User/request-withdrawal.html
ERROR - 2019-06-13 18:52:50 --> 404 Page Not Found: User/index.html
ERROR - 2019-06-13 18:53:44 --> 404 Page Not Found: Indexhtml/index
