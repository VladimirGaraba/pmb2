<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-22 02:23:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-22 02:40:46 --> 404 Page Not Found: Wordpress/wp-login.php
ERROR - 2019-06-22 04:34:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-22 04:36:13 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-22 05:19:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-22 06:02:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-22 06:49:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-22 08:45:15 --> 404 Page Not Found: Blog/wp-login.php
ERROR - 2019-06-22 11:15:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-22 12:06:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-22 12:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-22 14:21:44 --> 404 Page Not Found: Admin/withdrawals-requests.html
ERROR - 2019-06-22 14:21:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-22 14:37:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-22 14:37:47 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-22 14:38:32 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-22 14:49:37 --> 404 Page Not Found: Wp/wp-login.php
ERROR - 2019-06-22 16:51:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-22 16:51:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-22 16:51:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-22 16:52:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-22 19:18:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-22 19:18:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-22 20:48:36 --> 404 Page Not Found: Test/wp-login.php
ERROR - 2019-06-22 21:38:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-22 23:33:07 --> 404 Page Not Found: Well-known/security.txt
