<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-20 01:26:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-20 01:26:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-20 01:26:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-20 09:17:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-20 10:06:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-20 12:18:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-20 12:26:14 --> 404 Page Not Found: Pmb/admin
ERROR - 2019-06-20 12:26:22 --> 404 Page Not Found: Pmb/admin
ERROR - 2019-06-20 12:26:29 --> 404 Page Not Found: Pmb/admin
ERROR - 2019-06-20 12:26:33 --> 404 Page Not Found: Pmb/admin
ERROR - 2019-06-20 12:26:50 --> 404 Page Not Found: Pmb/admin
ERROR - 2019-06-20 22:18:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-20 22:18:06 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-20 22:19:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-20 22:19:33 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-20 22:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-20 22:28:50 --> 404 Page Not Found: Robotstxt/index
