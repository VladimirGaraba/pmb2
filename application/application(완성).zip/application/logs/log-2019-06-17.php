<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-17 01:47:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' $id' at line 2 - Invalid query: UPDATE `users` SET `verified` = 1
WHERE id, $id
ERROR - 2019-06-17 02:43:02 --> 404 Page Not Found: Front/css
ERROR - 2019-06-17 02:43:11 --> 404 Page Not Found: Back/assets
ERROR - 2019-06-17 04:51:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-17 04:57:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-17 08:54:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-17 08:56:09 --> Severity: Notice --> Undefined index: id /home/pmbcjykk/public_html/pmb2/application/models/User_Model.php 151
ERROR - 2019-06-17 08:59:57 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-17 08:59:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-17 09:04:46 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-17 09:33:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-17 09:39:40 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-17 09:39:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-17 09:39:53 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-17 10:11:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-17 10:22:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-17 10:53:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-17 10:54:52 --> 404 Page Not Found: Admin/withdrawals-requests.html
ERROR - 2019-06-17 10:54:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-17 15:05:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-17 15:10:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-17 15:10:39 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-17 15:12:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-17 15:12:59 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-17 15:17:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-17 16:20:58 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-17 16:31:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-17 16:35:31 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-17 16:37:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-17 20:05:33 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-17 20:25:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-17 21:09:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-17 21:09:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-17 21:15:35 --> Severity: Notice --> Object of class stdClass could not be converted to int /home/pmbcjykk/public_html/pmb2/application/controllers/Auth.php 46
ERROR - 2019-06-17 21:16:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-17 21:26:21 --> Severity: Notice --> Trying to get property 'email_key' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Auth.php 158
ERROR - 2019-06-17 21:27:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-17 21:27:45 --> Severity: Notice --> Trying to get property 'email_key' of non-object /home/pmbcjykk/public_html/pmb2/application/controllers/Auth.php 158
ERROR - 2019-06-17 21:37:29 --> Query error: Unknown column 'verified' in 'field list' - Invalid query: INSERT INTO `users` (`Name`, `Email`, `Username`, `Gender`, `Phone`, `State`, `Password`, `visit_count`, `DateRegistered`, `email_key`, `verified`) VALUES ('hfdhfd', 'qdsd55@outlook.com', 'okokdfs', 'Male', '12345342534', 'Ondo', '0b4e7a0e5fe84ad35fb5f95b9ceeac79', 0, '2019-06-17 21:37:29', '6f214f451feeee7914a3f0adf1c6092c', 1)
ERROR - 2019-06-17 21:58:42 --> Severity: Notice --> Undefined property: stdClass::$visit_count /home/pmbcjykk/public_html/pmb2/application/models/User_Model.php 116
ERROR - 2019-06-17 21:58:42 --> Severity: Notice --> Object of class stdClass could not be converted to int /home/pmbcjykk/public_html/pmb2/application/controllers/Auth.php 46
