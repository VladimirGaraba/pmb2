<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-24 05:50:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-24 06:14:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-24 06:15:29 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-24 06:30:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-24 07:27:02 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2019-06-24 09:19:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-24 09:20:03 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-24 09:20:41 --> 404 Page Not Found: Demo/contact-us
ERROR - 2019-06-24 09:20:55 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-24 09:20:55 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-24 09:20:55 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-24 09:20:55 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-24 09:22:24 --> 404 Page Not Found: Demo/images
ERROR - 2019-06-24 09:32:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-24 10:17:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-24 11:17:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-24 11:45:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-24 11:55:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-24 14:17:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-06-24 15:06:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-06-24 17:46:32 --> 404 Page Not Found: Wp-loginphp/index
